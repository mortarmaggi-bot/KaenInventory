package ru.inventory.app

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "branches", indices = [Index(value=["name"], unique=true)])
data class Branch(@PrimaryKey(autoGenerate=true) val id:Long=0, val name:String, val address:String="")
@Entity(tableName = "cabinets", indices=[Index("branchId")])
data class Cabinet(@PrimaryKey(autoGenerate=true) val id:Long=0, val branchId:Long, val name:String)
@Entity(tableName = "workplaces", indices=[Index("cabinetId")])
data class Workplace(@PrimaryKey(autoGenerate=true) val id:Long=0, val cabinetId:Long, val name:String)
@Entity(tableName="assets", indices=[Index(value=["inventoryNumber"], unique=true), Index("branchId"), Index("cabinetId"), Index("workplaceId")])
data class Asset(
 @PrimaryKey(autoGenerate=true) val id:Long=0, val inventoryNumber:String, val serialNumber:String="", val name:String,
 val brand:String="", val model:String="", @ColumnInfo(defaultValue="'Прочее'") val type:String="Прочее", val branchId:Long, val cabinetId:Long, val workplaceId:Long?=null,
 val condition:String="Исправно", val notes:String="", val photoPath:String="", val active:Boolean=true,
 val updatedAt:Long=System.currentTimeMillis(), @ColumnInfo(defaultValue="''") val acquiredDate:String="", @ColumnInfo(defaultValue="0.0") val cost:Double=0.0
)
@Entity(tableName="asset_types", indices=[Index(value=["name"], unique=true)])
data class AssetType(@PrimaryKey(autoGenerate=true) val id:Long=0, val name:String, @ColumnInfo(defaultValue="'devices'") val iconKey:String="devices")
@Entity(tableName="movements", indices=[Index("assetId")])
data class Movement(
 @PrimaryKey(autoGenerate=true) val id:Long=0, val assetId:Long, val inventoryNumber:String, val assetName:String,
 val fromBranch:String, val fromCabinet:String, val fromWorkplace:String, val toBranch:String, val toCabinet:String,
 val toWorkplace:String, val movedAt:Long=System.currentTimeMillis(), val reason:String="", val comment:String=""
)
@Entity(tableName="audits", indices=[Index("branchId")])
data class Audit(@PrimaryKey(autoGenerate=true) val id:Long=0, val title:String, val branchId:Long?=null, val startedAt:Long=System.currentTimeMillis(), val completedAt:Long?=null)
@Entity(tableName="audit_items", indices=[Index("auditId"), Index("assetId")])
data class AuditItem(
 @PrimaryKey(autoGenerate=true) val id:Long=0, val auditId:Long, val assetId:Long, val inventoryNumber:String,
 val assetName:String, val expectedLocation:String, val actualLocation:String="", val status:String="Ожидает проверки",
 val notes:String="", val checkedAt:Long?=null
)

@Dao interface InventoryDao {
 @Query("SELECT * FROM branches ORDER BY name") fun branches():Flow<List<Branch>>
 @Query("SELECT * FROM cabinets ORDER BY name") fun cabinets():Flow<List<Cabinet>>
 @Query("SELECT * FROM workplaces ORDER BY name") fun workplaces():Flow<List<Workplace>>
 @Query("SELECT * FROM assets WHERE active=1 ORDER BY name") fun assets():Flow<List<Asset>>
 @Query("SELECT * FROM assets WHERE active=0 ORDER BY updatedAt DESC") fun archivedAssets():Flow<List<Asset>>
 @Query("SELECT * FROM assets ORDER BY name") suspend fun allAssets():List<Asset>
 @Query("SELECT * FROM branches ORDER BY name") suspend fun allBranches():List<Branch>
 @Query("SELECT * FROM cabinets ORDER BY name") suspend fun allCabinets():List<Cabinet>
 @Query("SELECT * FROM workplaces ORDER BY name") suspend fun allWorkplaces():List<Workplace>
 @Query("SELECT * FROM asset_types ORDER BY name") fun assetTypes():Flow<List<AssetType>>
 @Insert(onConflict=OnConflictStrategy.IGNORE) suspend fun addAssetType(v:AssetType):Long
 @Update suspend fun updateAssetType(v:AssetType)
 @Query("DELETE FROM asset_types WHERE id=:id") suspend fun deleteAssetType(id:Long)
 @Query("SELECT * FROM movements ORDER BY movedAt DESC") fun movements():Flow<List<Movement>>
 @Query("SELECT * FROM audits ORDER BY startedAt DESC") fun audits():Flow<List<Audit>>
 @Query("SELECT * FROM audit_items WHERE auditId=:auditId ORDER BY inventoryNumber") fun auditItems(auditId:Long):Flow<List<AuditItem>>
 @Query("SELECT * FROM audit_items WHERE auditId=:auditId") suspend fun auditItemsOnce(auditId:Long):List<AuditItem>
 @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun addBranch(v:Branch):Long
 @Update suspend fun updateBranch(v:Branch)
 @Update suspend fun updateCabinet(v:Cabinet)
 @Update suspend fun updateWorkplace(v:Workplace)
 @Query("DELETE FROM branches WHERE id=:id AND NOT EXISTS(SELECT 1 FROM cabinets WHERE branchId=:id) AND NOT EXISTS(SELECT 1 FROM assets WHERE branchId=:id) AND NOT EXISTS(SELECT 1 FROM audits WHERE branchId=:id)")
 suspend fun deleteBranchIfEmpty(id:Long):Int
 @Query("DELETE FROM cabinets WHERE id=:id AND NOT EXISTS(SELECT 1 FROM workplaces WHERE cabinetId=:id) AND NOT EXISTS(SELECT 1 FROM assets WHERE cabinetId=:id)")
 suspend fun deleteCabinetIfEmpty(id:Long):Int
 @Query("DELETE FROM workplaces WHERE id=:id AND NOT EXISTS(SELECT 1 FROM assets WHERE workplaceId=:id)")
 suspend fun deleteWorkplaceIfEmpty(id:Long):Int
 @Insert suspend fun addCabinet(v:Cabinet):Long
 @Insert suspend fun addWorkplace(v:Workplace):Long
 @Transaction suspend fun addCabinetWithDefaultWorkplaces(v:Cabinet):Long {
  val cabinetId = addCabinet(v)
  addWorkplace(Workplace(cabinetId=cabinetId, name="1 рабочее место"))
  addWorkplace(Workplace(cabinetId=cabinetId, name="2 рабочее место"))
  return cabinetId
 }
 @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun addAsset(v:Asset):Long
 @Update suspend fun updateAsset(v:Asset)
 @Query("UPDATE assets SET active=0, branchId=0, cabinetId=0, workplaceId=NULL, updatedAt=:now WHERE id=:id") suspend fun archiveAsset(id:Long,now:Long)
 @Query("UPDATE assets SET active=1, branchId=:branchId, cabinetId=:cabinetId, workplaceId=:workplaceId, updatedAt=:now WHERE id=:id") suspend fun restoreAsset(id:Long,branchId:Long,cabinetId:Long,workplaceId:Long?,now:Long)
 @Insert suspend fun addMovement(v:Movement)
 @Insert suspend fun addAudit(v:Audit):Long
 @Insert suspend fun addAuditItems(v:List<AuditItem>)
 @Update suspend fun updateAuditItem(v:AuditItem)
 @Query("UPDATE audits SET completedAt=:at WHERE id=:id") suspend fun completeAudit(id:Long,at:Long)
 @Query("SELECT * FROM assets WHERE id=:id") suspend fun assetById(id:Long):Asset?
 @Query("SELECT * FROM branches WHERE id=:id") suspend fun branchById(id:Long):Branch?
 @Query("SELECT * FROM cabinets WHERE id=:id") suspend fun cabinetById(id:Long):Cabinet?
 @Query("SELECT * FROM workplaces WHERE id=:id") suspend fun workplaceById(id:Long):Workplace?
 @Query("DELETE FROM audit_items") suspend fun clearAuditItems()
 @Query("DELETE FROM audits") suspend fun clearAudits()
 @Query("DELETE FROM movements") suspend fun clearMovements()
 @Query("DELETE FROM assets") suspend fun clearAssets()
 @Query("DELETE FROM workplaces") suspend fun clearWorkplaces()
 @Query("DELETE FROM cabinets") suspend fun clearCabinets()
 @Query("DELETE FROM branches") suspend fun clearBranches()
 @Transaction suspend fun clearAllData() { clearAuditItems(); clearAudits(); clearMovements(); clearAssets(); clearWorkplaces(); clearCabinets(); clearBranches() }
}

@Database(entities=[Branch::class,Cabinet::class,Workplace::class,Asset::class,AssetType::class,Movement::class,Audit::class,AuditItem::class],version=4,exportSchema=false)
abstract class InventoryDatabase:RoomDatabase(){
 abstract fun dao():InventoryDao
 companion object {
  private val MIGRATION_2_3 = object : Migration(2,3) {
   override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE assets ADD COLUMN type TEXT NOT NULL DEFAULT 'Прочее'")
   }
  }
  private val MIGRATION_3_4 = object : Migration(3,4) {
   override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE assets ADD COLUMN acquiredDate TEXT NOT NULL DEFAULT ''")
    db.execSQL("ALTER TABLE assets ADD COLUMN cost REAL NOT NULL DEFAULT 0.0")
    db.execSQL("CREATE TABLE IF NOT EXISTS asset_types (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, iconKey TEXT NOT NULL DEFAULT 'devices')")
    db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_asset_types_name ON asset_types(name)")
    listOf("Системный блок","Монитор","Принтер","IP-телефон","Смартфон","ИБП","МФУ","Маршрутизатор","Коммутатор","Сервер","Координатор","Ноутбук","Прочее").forEach { name -> db.execSQL("INSERT OR IGNORE INTO asset_types(name,iconKey) VALUES('$name','devices')") }
   }
  }
  @Volatile private var INSTANCE:InventoryDatabase?=null
  fun get(context:Context):InventoryDatabase=INSTANCE?: synchronized(this){INSTANCE?:Room.databaseBuilder(context.applicationContext,InventoryDatabase::class.java,"inventory.db").addMigrations(MIGRATION_2_3, MIGRATION_3_4).build().also{INSTANCE=it}}
  fun closeForRestore(){INSTANCE?.close();INSTANCE=null}
 }
}
