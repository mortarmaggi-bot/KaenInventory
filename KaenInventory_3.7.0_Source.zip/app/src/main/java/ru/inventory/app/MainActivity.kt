@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ru.inventory.app

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Chair
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.text.NumberFormat
import java.util.Date
import java.util.Locale
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

private fun typeIcon(key: String): String = when (key) {
    "system_unit" -> "🖥️📦"; "monitor" -> "🖥️"; "printer" -> "🖨️"; "phone" -> "☎️"
    "smartphone" -> "📱"; "battery" -> "🔋"; "mfp" -> "🖨️📄"; "router" -> "📡"
    "switch" -> "🔀"; "server" -> "🗃️"; "coordinator" -> "🎛️"; "laptop" -> "💻"
    "network" -> "🌐"; "nas" -> "💽"; "rack" -> "🗂️"; "access_point" -> "📶"
    "camera" -> "📷"; "patch_panel" -> "🔌"; "scanner" -> "📠"; "converter" -> "🔗"
    "barcode" -> "▥"; "projector" -> "📽️"; "tablet" -> "📲"; "dock" -> "🔌"
    "webcam" -> "🎥"; "firewall" -> "🛡️"; "cable" -> "🧵"; "ups" -> "🔋"
    "headset" -> "🎧"; "keyboard" -> "⌨️"; "mouse" -> "🖱️"; "storage" -> "💾"
    "devices" -> "🧰"; else -> "🧰"
}

private fun dateText(value: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru")).format(Date(value))

// Multiple images are stored as newline-separated paths in the existing photoPath column.
// This keeps the Room schema and all existing user data intact; legacy single paths remain valid.
private fun assetPhotoPaths(value: String): List<String> = value.split('\n').map { it.trim() }.filter { it.isNotBlank() }

@Composable private fun AssetPhoto(path: String, modifier: Modifier = Modifier, fallback: @Composable () -> Unit = {}) {
    val bitmap = remember(path) { runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1000 || bounds.outHeight / sample > 1000) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull() }
    if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = "Фотография имущества", modifier = modifier, contentScale = ContentScale.Crop)
    else fallback()
}

@Composable private fun PhotoPlaceholder(modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(14.dp), color = Color(0xFFE7F3F6)) {
        Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Inventory2, contentDescription = null, tint = Color(0xFF39869A), modifier = Modifier.size(25.dp)) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    private lateinit var dao: InventoryDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dao = InventoryDatabase.get(this).dao()
        setContent {
            // KaenInventory 3.0 visual system: a complete app-shell redesign.
            val kaenColors = lightColorScheme(
                primary = Color(0xFF126B78),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFD8F2F0),
                onPrimaryContainer = Color(0xFF103F48),
                secondary = Color(0xFF18A6A0),
                onSecondary = Color.White,
                secondaryContainer = Color(0xFFDDF6F1),
                onSecondaryContainer = Color(0xFF124D49),
                tertiary = Color(0xFF397DB5),
                background = Color(0xFFF2F6F8),
                surface = Color(0xFFFFFFFF),
                surfaceVariant = Color(0xFFE8F0F3),
                onSurface = Color(0xFF142F3B),
                onSurfaceVariant = Color(0xFF607984),
                outline = Color(0xFFD2E0E5),
                outlineVariant = Color(0xFFE5EDF0),
                error = Color(0xFFB94F50)
            )
            val kaenShapes = Shapes(
                extraSmall = RoundedCornerShape(10.dp),
                small = RoundedCornerShape(14.dp),
                medium = RoundedCornerShape(20.dp),
                large = RoundedCornerShape(26.dp),
                extraLarge = RoundedCornerShape(32.dp)
            )
            val baseTypography = Typography()
            val kaenTypography = baseTypography.copy(
                headlineSmall = baseTypography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                titleLarge = baseTypography.titleLarge.copy(fontWeight = FontWeight.Bold),
                titleMedium = baseTypography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                titleSmall = baseTypography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                labelLarge = baseTypography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
            )
            MaterialTheme(colorScheme = kaenColors, shapes = kaenShapes, typography = kaenTypography) {
                val branches by dao.branches().collectAsStateWithLifecycle(emptyList())
                val cabinets by dao.cabinets().collectAsStateWithLifecycle(emptyList())
                val workplaces by dao.workplaces().collectAsStateWithLifecycle(emptyList())
                val assets by dao.assets().collectAsStateWithLifecycle(emptyList())
                val archivedAssets by dao.archivedAssets().collectAsStateWithLifecycle(emptyList())
                val movements by dao.movements().collectAsStateWithLifecycle(emptyList())
                val audits by dao.audits().collectAsStateWithLifecycle(emptyList())
                val assetTypes by dao.assetTypes().collectAsStateWithLifecycle(emptyList())
                LaunchedEffect(Unit) {
                    val defaults = listOf("Системный блок" to "system_unit", "Монитор" to "monitor", "Принтер" to "printer", "IP-телефон" to "phone", "Смартфон" to "smartphone", "ИБП" to "battery", "МФУ" to "mfp", "Маршрутизатор" to "router", "Коммутатор" to "switch", "Сервер" to "server", "Координатор" to "coordinator", "Ноутбук" to "laptop", "Прочее" to "devices")
                    defaults.forEach { (name, icon) -> dao.addAssetType(AssetType(name=name, iconKey=icon)) }
                    assetTypes.forEach { type -> defaults.firstOrNull { it.first == type.name }?.let { pair -> if (type.iconKey == "devices") dao.updateAssetType(type.copy(iconKey=pair.second)) } }
                }

                LaunchedEffect(assetTypes) {
                    val defaults = mapOf("Системный блок" to "system_unit", "Монитор" to "monitor", "Принтер" to "printer", "IP-телефон" to "phone", "Смартфон" to "smartphone", "ИБП" to "battery", "МФУ" to "mfp", "Маршрутизатор" to "router", "Коммутатор" to "switch", "Сервер" to "server", "Координатор" to "coordinator", "Ноутбук" to "laptop", "Прочее" to "devices")
                    assetTypes.forEach { type -> defaults[type.name]?.let { icon -> if (type.iconKey == "devices") dao.updateAssetType(type.copy(iconKey=icon)) } }
                }

                var tab by remember { mutableIntStateOf(0) }
                var search by remember { mutableStateOf("") }
                var branchFilter by remember { mutableLongStateOf(0L) }
                var conditionFilter by remember { mutableStateOf("Все состояния") }
                var cabinetFilter by remember { mutableLongStateOf(0L) }
                var workplaceFilter by remember { mutableLongStateOf(0L) }
                var historyFilter by remember { mutableStateOf("") }
                var showAssetDialog by remember { mutableStateOf(false) }
                var selectedAsset by remember { mutableStateOf<Asset?>(null) }
                var movingAsset by remember { mutableStateOf<Asset?>(null) }
                var servicingAsset by remember { mutableStateOf<Asset?>(null) }
                var serviceStatusSuggestion by remember { mutableStateOf<Pair<Asset, String>?>(null) }
                var archiveConfirmAsset by remember { mutableStateOf<Asset?>(null) }
                var restoreTarget by remember { mutableStateOf<Asset?>(null) }
                var editingAsset by remember { mutableStateOf<Asset?>(null) }
                var showStructureDialog by remember { mutableStateOf(false) }
                var editingStructure by remember { mutableStateOf<Triple<String, Long, String>?>(null) }
                var deletingStructure by remember { mutableStateOf<Triple<String, Long, String>?>(null) }
                var selectedAuditId by remember { mutableStateOf<Long?>(null) }
                var auditBranchId by remember { mutableLongStateOf(0L) }
                var pendingImportRows by remember { mutableStateOf(loadPendingExcelImport(this@MainActivity)) }
                LaunchedEffect(pendingImportRows) { savePendingExcelImport(this@MainActivity, pendingImportRows) }
                val excelImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) lifecycleScope.launch {
                        try {
                            pendingImportRows = ExcelInventoryImporter.read(this@MainActivity, uri)
                            Toast.makeText(this@MainActivity, "Прочитано строк: ${pendingImportRows.size}. Проверьте их перед добавлением.", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "Не удалось прочитать Excel: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
                var pendingOcrNumber by remember { mutableStateOf("") }
                var scanPhotoFile by remember { mutableStateOf<File?>(null) }
                val inventoryNumberCamera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
                    val photo = scanPhotoFile
                    if (success && photo != null) {
                        try {
                            val image = InputImage.fromFilePath(this@MainActivity, Uri.fromFile(photo))
                            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                            recognizer.process(image)
                                .addOnSuccessListener { result ->
                                    val recognized = result.textBlocks.joinToString(" ") { it.text }.trim()
                                    val candidates = Regex("[A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9._/-]{2,}").findAll(recognized).map { it.value }.toList()
                                    pendingOcrNumber = candidates.firstOrNull { it.any(Char::isDigit) } ?: recognized
                                    if (pendingOcrNumber.isBlank()) Toast.makeText(this@MainActivity, "Не удалось распознать номер. Попробуйте ещё раз или введите вручную.", Toast.LENGTH_LONG).show()
                                }
                                .addOnFailureListener { error -> Toast.makeText(this@MainActivity, "Ошибка распознавания: ${error.message}", Toast.LENGTH_LONG).show() }
                                .addOnCompleteListener { recognizer.close(); photo.delete() }
                        } catch (e: Exception) {
                            photo.delete()
                            Toast.makeText(this@MainActivity, "Не удалось обработать снимок: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    } else photo?.delete()
                }
                val backupCreator = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
                    if (uri != null) lifecycleScope.launch {
                        try {
                            Backup.create(this@MainActivity, uri)
                            Toast.makeText(this@MainActivity, "Резервная копия создана", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "Ошибка резервного копирования: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
                val backupOpener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) lifecycleScope.launch {
                        try {
                            Backup.restore(this@MainActivity, uri)
                            Toast.makeText(this@MainActivity, "Копия восстановлена", Toast.LENGTH_LONG).show()
                            recreate()
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "Ошибка восстановления: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }

                val visibleAssets = assets.filter { asset ->
                    val matchesText = search.isBlank() || listOf(asset.inventoryNumber, asset.serialNumber, asset.name, asset.brand, asset.model).any { it.contains(search.trim(), true) }
                    val matchesBranch = branchFilter == 0L || asset.branchId == branchFilter
                    val matchesCondition = conditionFilter == "Все состояния" || asset.condition == conditionFilter
                    val matchesCabinet = cabinetFilter == 0L || asset.cabinetId == cabinetFilter
                    val matchesWorkplace = workplaceFilter == 0L || asset.workplaceId == workplaceFilter
                    matchesText && matchesBranch && matchesCondition && matchesCabinet && matchesWorkplace
                }.sortedBy { it.inventoryNumber.lowercase(Locale("ru")) }

                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    topBar = {
                        Surface(color = Color.White, shadowElevation = 3.dp) {
                            Row(
                                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.size(48.dp),
                                    shape = RoundedCornerShape(17.dp),
                                    color = MaterialTheme.colorScheme.primary
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.Inventory2, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
                                    }
                                }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("KaenInventory", style = MaterialTheme.typography.titleLarge, color = Color(0xFF123B48), fontWeight = FontWeight.ExtraBold)
                                    Text("УПРАВЛЕНИЕ ИМУЩЕСТВОМ", style = MaterialTheme.typography.labelSmall, color = Color(0xFF718892), letterSpacing = androidx.compose.ui.unit.TextUnit.Unspecified)
                                }
                                Surface(
                                    shape = RoundedCornerShape(15.dp),
                                    color = Color(0xFFE8F5F4),
                                    modifier = Modifier.size(46.dp).clickable { tab = 6 }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.Settings, contentDescription = "Настройки", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(23.dp))
                                    }
                                }
                            }
                        }
                    },
                    bottomBar = {
                        Surface(color = Color.White, shadowElevation = 12.dp) {
                            Row(
                                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 5.dp, vertical = 7.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val navItems = listOf(
                                    Triple("Обзор", Icons.Filled.Home, 0),
                                    Triple("Структура", Icons.Filled.AccountTree, 1),
                                    Triple("Имущество", Icons.Filled.Inventory2, 2),
                                    Triple("Проверки", Icons.Filled.FactCheck, 3),
                                    Triple("Архив", Icons.Filled.Archive, 4),
                                    Triple("История", Icons.Filled.History, 5)
                                )
                                navItems.forEach { (label, icon, index) ->
                                    val selected = tab == index
                                    Column(
                                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable { tab = index }
                                            .background(if (selected) Color(0xFFE2F3F1) else Color.Transparent)
                                            .padding(horizontal = 2.dp, vertical = 7.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Icon(icon, contentDescription = label, tint = if (selected) Color(0xFF126B78) else Color(0xFF84969D), modifier = Modifier.size(21.dp))
                                        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, color = if (selected) Color(0xFF126B78) else Color(0xFF84969D), fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
                                    }
                                }
                            }
                        }
                    }
                ) { padding ->
                    Column(Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 16.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        when (tab) {
                            0 -> OverviewScreen(
                                branches, cabinets, workplaces, assets, archivedAssets.size, movements, audits,
                                onNavigate = { tab = it },
                                onAddAsset = { editingAsset = null; showAssetDialog = true },
                                onNewAudit = {
                                    lifecycleScope.launch {
                                        val newId = dao.addAudit(Audit(title = "Инвентаризация ${dateText(System.currentTimeMillis())}"))
                                        dao.addAuditItems(assets.map { asset ->
                                            AuditItem(auditId = newId, assetId = asset.id, inventoryNumber = asset.inventoryNumber,
                                                assetName = asset.name, expectedLocation = assetLocation(asset, branches, cabinets, workplaces))
                                        })
                                        selectedAuditId = newId
                                        tab = 3
                                    }
                                }
                            )
                            1 -> StructureScreen(
                                branches, cabinets, workplaces, assets, assetTypes,
                                onAdd = { showStructureDialog = true },
                                onOpenAsset = { selectedAsset = it },
                                onHistory = { historyFilter = it; tab = 5 },
                                onEdit = { kind, id, name -> editingStructure = Triple(kind, id, name) },
                                onDelete = { kind, id, name -> deletingStructure = Triple(kind, id, name) }
                            )
                            2 -> AssetsScreen(
                                assets = visibleAssets, branches = branches, cabinets = cabinets, workplaces = workplaces, assetTypes = assetTypes,
                                search = search, onSearch = { search = it }, branchFilter = branchFilter, onBranchFilter = { branchFilter = it; cabinetFilter = 0L; workplaceFilter = 0L },
                                cabinetFilter = cabinetFilter, onCabinetFilter = { cabinetFilter = it },
                                workplaceFilter = workplaceFilter, onWorkplaceFilter = { workplaceFilter = it },
                                conditionFilter = conditionFilter, onConditionFilter = { conditionFilter = it },
                                onReset = { branchFilter = 0L; cabinetFilter = 0L; workplaceFilter = 0L; conditionFilter = "Все состояния" },
                                onAdd = { editingAsset = null; showAssetDialog = true },
                                onEdit = { editingAsset = it; showAssetDialog = true },
                                onOpenAsset = { selectedAsset = it },
                                onArchive = { asset -> lifecycleScope.launch {
                                    dao.addMovement(Movement(
                                        assetId=asset.id, inventoryNumber=asset.inventoryNumber, assetName=asset.name,
                                        fromBranch=branches.firstOrNull { it.id==asset.branchId }?.name.orEmpty(),
                                        fromCabinet=cabinets.firstOrNull { it.id==asset.cabinetId }?.name.orEmpty(),
                                        fromWorkplace=workplaces.firstOrNull { it.id==asset.workplaceId }?.name.orEmpty(),
                                        toBranch="Архив", toCabinet="", toWorkplace="", reason="Архивирование"
                                    ))
                                    dao.archiveAsset(asset.id, System.currentTimeMillis())
                                    Toast.makeText(this@MainActivity, "${asset.name} перемещено в архив", Toast.LENGTH_SHORT).show()
                                } },
                                onHistory = { historyFilter = it.inventoryNumber; tab = 5 }
                            )
                            3 -> AuditsScreen(
                                audits = audits, branches = branches, cabinets = cabinets, selectedAuditId = selectedAuditId,
                                auditBranchId = auditBranchId, onBranch = { auditBranchId = it },
                                onSelect = { selectedAuditId = if (it < 0L) null else it },
                                onStart = {
                                    lifecycleScope.launch {
                                        val newId = dao.addAudit(Audit(title = "Инвентаризация ${dateText(System.currentTimeMillis())}", branchId = auditBranchId.takeIf { it != 0L }))
                                        val source = assets.filter { auditBranchId == 0L || it.branchId == auditBranchId }
                                        dao.addAuditItems(source.map { asset ->
                                            AuditItem(auditId = newId, assetId = asset.id, inventoryNumber = asset.inventoryNumber,
                                                assetName = asset.name, expectedLocation = assetLocation(asset, branches, cabinets, workplaces))
                                        })
                                        selectedAuditId = newId
                                    }
                                },
                                dao = dao,
                                scannedNumber = pendingOcrNumber,
                                onClearScannedNumber = { pendingOcrNumber = "" },
                                onScan = {
                                    val photo = File(cacheDir, "inventory_scan_${System.currentTimeMillis()}.jpg")
                                    scanPhotoFile = photo
                                    val uri = androidx.core.content.FileProvider.getUriForFile(this@MainActivity, "$packageName.provider", photo)
                                    inventoryNumberCamera.launch(uri)
                                },
                                onExport = { id, rows ->
                                    lifecycleScope.launch {
                                        val file = Exporter.auditXlsx(this@MainActivity, audits.firstOrNull { it.id == id }, rows)
                                        shareFile(file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                                    }
                                },
                                onComplete = { id -> lifecycleScope.launch { dao.completeAudit(id, System.currentTimeMillis()) } },
                                onSetStatus = { row, status -> lifecycleScope.launch { dao.updateAuditItem(row.copy(status = status, actualLocation = if (status == "Найдено") row.expectedLocation else row.actualLocation, checkedAt = System.currentTimeMillis())) } }
                            )
                            4 -> ArchiveScreen(archivedAssets, movements, onOpenAsset = { selectedAsset = it }, onRestoreAsset = { restoreTarget = it })
                            5 -> MovementsScreen(movements, branches, cabinets, workplaces, query = historyFilter, onQuery = { historyFilter = it }, onExport = { selected -> lifecycleScope.launch {
                                val file = Exporter.movementsXlsx(this@MainActivity, selected)
                                shareFile(file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                            } })
                            else -> MoreScreen(
                                movements = movements, assetTypes = assetTypes, branches = branches, cabinets = cabinets, workplaces = workplaces,
                                onAddType = { name, iconKey -> lifecycleScope.launch { dao.addAssetType(AssetType(name=name.trim(), iconKey=iconKey)) } },
                                onUpdateType = { type -> lifecycleScope.launch { dao.updateAssetType(type) } },
                                onDeleteType = { id -> lifecycleScope.launch { dao.deleteAssetType(id) } },
                                onClearTestData = { lifecycleScope.launch {
                                    try { dao.clearAllData(); Toast.makeText(this@MainActivity, "Данные очищены", Toast.LENGTH_LONG).show() }
                                    catch (e: Exception) { Toast.makeText(this@MainActivity, "Не удалось очистить данные: ${e.message}", Toast.LENGTH_LONG).show() }
                                } },
                                historyFilter = historyFilter, onHistoryFilter = { historyFilter = it },
                                onExportXlsx = {
                                    lifecycleScope.launch {
                                        val file = Exporter.assetsXlsx(this@MainActivity, dao.allAssets().filter { it.active }, dao.allBranches(), dao.allCabinets(), dao.allWorkplaces())
                                        shareFile(file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                                    }
                                },
                                onExportHistoryXlsx = { selectedMovements ->
                                    lifecycleScope.launch {
                                        val file = Exporter.movementsXlsx(this@MainActivity, selectedMovements)
                                        shareFile(file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                                    }
                                },
                                onExportPdf = {
                                    lifecycleScope.launch {
                                        val file = Exporter.assetsPdf(this@MainActivity, dao.allAssets().filter { it.active }, dao.allBranches(), dao.allCabinets(), dao.allWorkplaces())
                                        shareFile(file, "application/pdf")
                                    }
                                },
                                onBackup = { backupCreator.launch("inventory-backup-${System.currentTimeMillis()}.zip") },
                                onRestore = { backupOpener.launch(arrayOf("application/zip", "application/octet-stream")) },
                                onImportExcel = { excelImportLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream", "*/*")) }
                            )
                        }
                    }
                }

                if (pendingImportRows.isNotEmpty()) ExcelImportReviewDialog(
                    rows = pendingImportRows, branches = branches, cabinets = cabinets, workplaces = workplaces,
                    existingNumbers = (assets + archivedAssets).map { it.inventoryNumber.trim().lowercase(Locale.ROOT) }.toSet(), assetTypes = assetTypes,
                    characteristicTypes = readCustomCharacteristics(this@MainActivity).associate { it.name to it.assetTypes.toSet() },
                    onDismiss = { pendingImportRows = emptyList() },
                    onDraftChange = { pendingImportRows = it },
                    onImport = { readyRows, newTypes, newCharacteristics, preSkipped ->
                        lifecycleScope.launch {
                            var added = 0; var skipped = 0
                            try {
                                newTypes.forEach { dao.addAssetType(AssetType(name = it, iconKey = "devices")) }
                                val existingDefinitions = readCustomCharacteristics(this@MainActivity).toMutableList()
                                val createdDefinitions = newCharacteristics.associateWith { name ->
                                    val typesForField = readyRows.filter { name in it.row.customValues }.map { it.row.type }.distinct()
                                    val existingIndex = existingDefinitions.indexOfFirst { it.name == name }
                                    if (existingIndex >= 0) {
                                        val existing = existingDefinitions[existingIndex]
                                        val updated = existing.copy(assetTypes = (existing.assetTypes + typesForField).distinct())
                                        existingDefinitions[existingIndex] = updated
                                        updated
                                    } else CustomCharacteristic(id = "import_${java.util.UUID.randomUUID()}", name = name,
                                        kind = "Текст", assetTypes = typesForField)
                                }
                                val newDefinitions = createdDefinitions.values.filter { definition -> existingDefinitions.none { it.id == definition.id } }
                                writeCustomCharacteristics(this@MainActivity, existingDefinitions + newDefinitions)
                                readyRows.forEach { ready ->
                                    val row = ready.row
                                    try {
                                        val newAssetId = dao.addAsset(Asset(inventoryNumber = row.inventoryNumber.trim(), name = row.displayName.trim(),
                                            serialNumber = row.serialNumber.trim(), brand = row.brand, model = row.model, type = row.type.trim(),
                                            branchId = ready.branchId, cabinetId = ready.cabinetId, workplaceId = ready.workplaceId, notes = row.notes.trim()))
                                        val customJson = org.json.JSONObject()
                                        row.customValues.forEach { (fieldName, value) ->
                                            val definition = existingDefinitions.firstOrNull { it.name == fieldName } ?: createdDefinitions[fieldName]
                                            if (definition != null) customJson.put(definition.id, value)
                                        }
                                        if (customJson.length() > 0) getSharedPreferences("kaen_asset_characteristics", MODE_PRIVATE)
                                            .edit().putString("asset_$newAssetId", customJson.toString()).apply()
                                        added++
                                    } catch (_: Exception) { skipped++ }
                                }
                                pendingImportRows = emptyList()
                                Toast.makeText(this@MainActivity, "Импорт завершён. Добавлено: $added, пропущено: ${skipped + preSkipped}.", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                Toast.makeText(this@MainActivity, "Ошибка импорта: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                )

                restoreTarget?.let { archived ->
                    RestoreAssetDialog(archived, branches, cabinets, workplaces,
                        onDismiss = { restoreTarget = null },
                        onRestore = { branchId, cabinetId, workplaceId -> lifecycleScope.launch {
                            try {
                                dao.restoreAsset(archived.id, branchId, cabinetId, workplaceId, System.currentTimeMillis())
                                dao.addMovement(Movement(assetId=archived.id, inventoryNumber=archived.inventoryNumber, assetName=archived.name,
                                    fromBranch="Архив", fromCabinet="", fromWorkplace="",
                                    toBranch=branches.firstOrNull { it.id==branchId }?.name.orEmpty(),
                                    toCabinet=cabinets.firstOrNull { it.id==cabinetId }?.name.orEmpty(),
                                    toWorkplace=workplaces.firstOrNull { it.id==workplaceId }?.name.orEmpty(), reason="Восстановление из архива"))
                                Toast.makeText(this@MainActivity, "${archived.name} восстановлено", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) { Toast.makeText(this@MainActivity, "Ошибка восстановления: ${e.message}", Toast.LENGTH_LONG).show() }
                            restoreTarget = null
                        } })
                }

                selectedAsset?.let { a ->
                    val branchName = if (!a.active) "Архив" else branches.firstOrNull { it.id == a.branchId }?.name.orEmpty()
                    val cabinetName = if (!a.active) "—" else cabinets.firstOrNull { it.id == a.cabinetId }?.name.orEmpty()
                    val workplaceName = if (!a.active) "—" else workplaces.firstOrNull { it.id == a.workplaceId }?.name ?: "Общее имущество кабинета"
                    val photos = assetPhotoPaths(a.photoPath)
                    ModalBottomSheet(
                        onDismissRequest = { selectedAsset = null },
                        containerColor = Color.White,
                        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                        dragHandle = { BottomSheetDefaults.DragHandle(color = Color(0xFFB8CDD3)) }
                    ) {
                        Column(
                            Modifier.fillMaxWidth().fillMaxHeight(0.88f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(13.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text("Карточка имущества", style = MaterialTheme.typography.labelMedium, color = Color(0xFF71858D))
                                    Text(a.name, style = MaterialTheme.typography.titleLarge, color = Color(0xFF123B5A))
                                    Text("Инвентарный № ${a.inventoryNumber}", style = MaterialTheme.typography.titleSmall, color = Color(0xFF008D9C))
                                }
                                IconButton(onClick = { selectedAsset = null }) { Icon(Icons.Filled.Close, contentDescription = "Закрыть") }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (photos.isNotEmpty()) AssetPhoto(photos.first(), Modifier.size(86.dp).clip(RoundedCornerShape(18.dp)))
                                else PhotoPlaceholder(Modifier.size(86.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Surface(shape = RoundedCornerShape(50), color = if (a.active) Color(0xFFE8F6EF) else Color(0xFFF0F3F6)) {
                                        Text(if (a.active) "В эксплуатации" else "В архиве", Modifier.padding(horizontal = 11.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium, color = if (a.active) Color(0xFF28764F) else Color(0xFF637782))
                                    }
                                    Surface(shape = RoundedCornerShape(50), color = if (a.condition.equals("Исправно", true)) Color(0xFFEAF5FA) else Color(0xFFFFF3E5)) {
                                        Text(a.condition, Modifier.padding(horizontal = 11.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium, color = Color(0xFF285D70))
                                    }
                                    Text(a.type, style = MaterialTheme.typography.bodySmall, color = Color(0xFF71858D))
                                }
                            }
                            if (photos.isNotEmpty()) {
                                Text("ФОТОГРАФИИ · ${photos.size}", style = MaterialTheme.typography.labelMedium, color = Color(0xFF087E9A))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                    items(photos) { path -> AssetPhoto(path, Modifier.size(116.dp).clip(RoundedCornerShape(15.dp))) }
                                }
                            }
                            Surface(color = Color(0xFFF3F8FA), shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Text("ХАРАКТЕРИСТИКИ", style = MaterialTheme.typography.labelMedium, color = Color(0xFF087E9A))
                                    AssetDetailRow("Серийный номер", a.serialNumber.ifBlank { "Не указан" })
                                    AssetDetailRow("Производитель", a.brand.ifBlank { "Не указан" })
                                    AssetDetailRow("Модель", a.model.ifBlank { "Не указана" })
                                    AssetDetailRow("Дата приобретения", a.acquiredDate.ifBlank { "Не указана" })
                                    AssetDetailRow("Первоначальная стоимость", if (a.cost > 0.0) "${NumberFormat.getNumberInstance(Locale("ru")).format(a.cost)} ₽" else "Не указана")
                                }
                            }
                            Surface(color = Color(0xFFF3F8FA), shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Text("МЕСТОПОЛОЖЕНИЕ", style = MaterialTheme.typography.labelMedium, color = Color(0xFF087E9A))
                                    AssetDetailRow("Филиал", branchName.ifBlank { "Не указан" })
                                    AssetDetailRow("Кабинет", cabinetName.ifBlank { "Не указан" })
                                    AssetDetailRow("Рабочее место", workplaceName)
                                }
                            }
                            Text("ИСТОРИЯ ОПЕРАЦИЙ", style = MaterialTheme.typography.labelMedium, color = Color(0xFF087E9A))
                            val assetHistory = movements.filter { it.assetId == a.id }.sortedBy { it.movedAt }
                            if (assetHistory.isEmpty()) Text("История перемещений пока не велась.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596))
                            else assetHistory.forEachIndexed { index, movement ->
                                val endAt = assetHistory.getOrNull(index + 1)?.movedAt
                                val destination = listOf(movement.toBranch, movement.toCabinet, movement.toWorkplace).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "Местоположение не указано" }
                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F8FB)), shape = RoundedCornerShape(14.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(destination, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF163D59))
                                        Text("С ${dateText(movement.movedAt)}${endAt?.let { " по ${dateText(it)}" } ?: " · последнее зафиксированное место"}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF52717A))
                                        if (movement.reason.isNotBlank()) Text(movement.reason, style = MaterialTheme.typography.labelSmall, color = Color(0xFF718596))
                                        if (movement.comment.isNotBlank()) Text(movement.comment, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                            if (a.active) {
                                OutlinedButton(onClick = { selectedAsset = null; servicingAsset = a }, modifier = Modifier.fillMaxWidth()) { Text("＋ Добавить запись об обслуживании") }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                if (a.active) Button(onClick = { selectedAsset = null; movingAsset = a }, modifier = Modifier.weight(1f)) { Text("Переместить") }
                                if (a.active) OutlinedButton(onClick = { selectedAsset = null; archiveConfirmAsset = a }, modifier = Modifier.weight(1f)) { Text("В архив") }
                                else Button(onClick = { restoreTarget = a; selectedAsset = null }, modifier = Modifier.weight(1f)) { Text("Восстановить") }
                            }
                            OutlinedButton(onClick = { selectedAsset = null; editingAsset = a; showAssetDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Редактировать") }
                            Spacer(Modifier.height(12.dp))
                        }
                    }
                }
                movingAsset?.let { target ->
                    MoveAssetDialog(target, assetTypes.firstOrNull { it.name == target.type }?.iconKey ?: "devices", branches, cabinets, workplaces,
                        onDismiss = { movingAsset = null },
                        onMove = { branchId, cabinetId, workplaceId ->
                            lifecycleScope.launch {
                                val now = System.currentTimeMillis()
                                val fromBranch = branches.firstOrNull { it.id == target.branchId }?.name.orEmpty()
                                val fromCabinet = cabinets.firstOrNull { it.id == target.cabinetId }?.name.orEmpty()
                                val fromWorkplace = workplaces.firstOrNull { it.id == target.workplaceId }?.name.orEmpty()
                                val toBranch = branches.firstOrNull { it.id == branchId }?.name.orEmpty()
                                val toCabinet = cabinets.firstOrNull { it.id == cabinetId }?.name.orEmpty()
                                val toWorkplace = workplaces.firstOrNull { it.id == workplaceId }?.name ?: "Общее имущество кабинета"
                                if (target.branchId != branchId || target.cabinetId != cabinetId || target.workplaceId != workplaceId) {
                                    dao.updateAsset(target.copy(branchId = branchId, cabinetId = cabinetId, workplaceId = workplaceId, updatedAt = now))
                                    dao.addMovement(Movement(assetId=target.id, inventoryNumber=target.inventoryNumber, assetName=target.name,
                                        fromBranch=fromBranch, fromCabinet=fromCabinet, fromWorkplace=fromWorkplace,
                                        toBranch=toBranch, toCabinet=toCabinet, toWorkplace=toWorkplace,
                                        movedAt=now, reason="Перемещение оборудования"))
                                    selectedAsset = null
                                    Toast.makeText(this@MainActivity, "Оборудование перемещено", Toast.LENGTH_SHORT).show()
                                }
                                movingAsset = null
                            }
                        })
                }

                servicingAsset?.let { target ->
                    ServiceEntrySheet(
                        asset = target,
                        onDismiss = { servicingAsset = null },
                        onSave = { description, comment ->
                            lifecycleScope.launch {
                                val branch = branches.firstOrNull { it.id == target.branchId }?.name.orEmpty()
                                val cabinet = cabinets.firstOrNull { it.id == target.cabinetId }?.name.orEmpty()
                                val workplace = workplaces.firstOrNull { it.id == target.workplaceId }?.name ?: "Общее имущество кабинета"
                                val details = listOf(description.trim(), comment.trim()).filter { it.isNotBlank() }.joinToString(" · ")
                                dao.addMovement(Movement(
                                    assetId = target.id, inventoryNumber = target.inventoryNumber, assetName = target.name,
                                    fromBranch = branch, fromCabinet = cabinet, fromWorkplace = workplace,
                                    toBranch = branch, toCabinet = cabinet, toWorkplace = workplace,
                                    movedAt = System.currentTimeMillis(), reason = "Обслуживание", comment = details
                                ))
                                val normalized = description.lowercase(Locale("ru"))
                                val suggested = when {
                                    listOf("неисправ", "полом", "дефект").any { normalized.contains(it) } -> "Неисправно"
                                    listOf("диагност", "провер", "ожида").any { normalized.contains(it) } -> "Требует проверки"
                                    listOf("ремонт", "исправ", "замен", "восстанов", "почин").any { normalized.contains(it) } -> "Исправно"
                                    else -> null
                                }
                                if (suggested != null && suggested != target.condition) serviceStatusSuggestion = target to suggested
                                servicingAsset = null
                                Toast.makeText(this@MainActivity, "Запись об обслуживании добавлена", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
                serviceStatusSuggestion?.let { (target, suggested) ->
                    AlertDialog(
                        onDismissRequest = { serviceStatusSuggestion = null },
                        title = { Text("Предложение по состоянию") },
                        text = { Text("По записи об обслуживании предлагается изменить состояние «${target.condition}» на «$suggested». Применить изменение?") },
                        confirmButton = {
                            TextButton(onClick = {
                                lifecycleScope.launch {
                                    val current = dao.assetById(target.id) ?: target
                                    dao.updateAsset(current.copy(condition = suggested, updatedAt = System.currentTimeMillis()))
                                    val branch = branches.firstOrNull { it.id == current.branchId }?.name.orEmpty()
                                    val cabinet = cabinets.firstOrNull { it.id == current.cabinetId }?.name.orEmpty()
                                    val workplace = workplaces.firstOrNull { it.id == current.workplaceId }?.name ?: "Общее имущество кабинета"
                                    dao.addMovement(Movement(
                                        assetId = current.id, inventoryNumber = current.inventoryNumber, assetName = current.name,
                                        fromBranch = branch, fromCabinet = cabinet, fromWorkplace = workplace,
                                        toBranch = branch, toCabinet = cabinet, toWorkplace = workplace,
                                        reason = "Изменение состояния", comment = "${target.condition} → $suggested"
                                    ))
                                }
                                serviceStatusSuggestion = null
                            }) { Text("Применить") }
                        },
                        dismissButton = { TextButton(onClick = { serviceStatusSuggestion = null }) { Text("Оставить без изменений") } }
                    )
                }
                archiveConfirmAsset?.let { target ->
                    AlertDialog(
                        onDismissRequest = { archiveConfirmAsset = null },
                        title = { Text("Отправить в архив?") },
                        text = { Text("${target.name} будет убрано из активного имущества и проверок. История размещений сохранится.") },
                        confirmButton = { TextButton(onClick = {
                            lifecycleScope.launch {
                                dao.addMovement(Movement(assetId=target.id, inventoryNumber=target.inventoryNumber, assetName=target.name,
                                    fromBranch=branches.firstOrNull { it.id==target.branchId }?.name.orEmpty(),
                                    fromCabinet=cabinets.firstOrNull { it.id==target.cabinetId }?.name.orEmpty(),
                                    fromWorkplace=workplaces.firstOrNull { it.id==target.workplaceId }?.name.orEmpty(),
                                    toBranch="Архив", toCabinet="", toWorkplace="", reason="Архивирование"))
                                dao.archiveAsset(target.id, System.currentTimeMillis())
                                selectedAsset = null
                                Toast.makeText(this@MainActivity, "${target.name} перемещено в архив", Toast.LENGTH_SHORT).show()
                            }
                            archiveConfirmAsset = null
                        }) { Text("Отправить в архив", color = MaterialTheme.colorScheme.error) } },
                        dismissButton = { TextButton(onClick = { archiveConfirmAsset = null }) { Text("Отмена") } }
                    )
                }

                if (showStructureDialog) {
                    StructureDialog(branches, cabinets, onDismiss = { showStructureDialog = false }) { kind, parentId, name ->
                        lifecycleScope.launch {
                            when (kind) {
                                "branch" -> dao.addBranch(Branch(name = name))
                                "cabinet" -> dao.addCabinetWithDefaultWorkplaces(Cabinet(branchId = parentId, name = name))
                                else -> dao.addWorkplace(Workplace(cabinetId = parentId, name = name))
                            }
                            showStructureDialog = false
                        }
                    }
                }
                editingStructure?.let { target ->
                    var editedName by remember(target) { mutableStateOf(target.third) }
                    AlertDialog(
                        onDismissRequest = { editingStructure = null },
                        title = { Text("Переименовать ${structureKindName(target.first)}") },
                        text = { OutlinedTextField(value = editedName, onValueChange = { editedName = it }, label = { Text("Новое название") }, singleLine = true) },
                        confirmButton = {
                            TextButton(onClick = {
                                if (editedName.isNotBlank()) lifecycleScope.launch {
                                    try {
                                        when (target.first) {
                                            "branch" -> dao.branchById(target.second)?.let { dao.updateBranch(it.copy(name = editedName.trim())) }
                                            "cabinet" -> dao.cabinetById(target.second)?.let { dao.updateCabinet(it.copy(name = editedName.trim())) }
                                            "workplace" -> dao.workplaceById(target.second)?.let { dao.updateWorkplace(it.copy(name = editedName.trim())) }
                                        }
                                        editingStructure = null
                                    } catch (e: Exception) {
                                        Toast.makeText(this@MainActivity, "Не удалось переименовать. Возможно, такое название уже существует.", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }) { Text("Сохранить") }
                        },
                        dismissButton = { TextButton(onClick = { editingStructure = null }) { Text("Отмена") } }
                    )
                }
                deletingStructure?.let { target ->
                    AlertDialog(
                        onDismissRequest = { deletingStructure = null },
                        title = { Text("Удалить ${structureKindName(target.first)}?") },
                        text = { Text("Удалить «${target.third}»? Удаление возможно только если нет связанных кабинетов, рабочих мест, имущества и привязанных проверок. Сначала переместите имущество и удалите дочерние элементы. История перемещений останется нетронутой.") },
                        confirmButton = {
                            TextButton(onClick = {
                                lifecycleScope.launch {
                                    val deleted = when (target.first) {
                                        "branch" -> dao.deleteBranchIfEmpty(target.second)
                                        "cabinet" -> dao.deleteCabinetIfEmpty(target.second)
                                        else -> dao.deleteWorkplaceIfEmpty(target.second)
                                    }
                                    Toast.makeText(this@MainActivity, if (deleted > 0) "Элемент удалён" else "Нельзя удалить: сначала переместите имущество и удалите дочерние элементы; архивные записи тоже учитываются", Toast.LENGTH_LONG).show()
                                    deletingStructure = null
                                }
                            }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                        },
                        dismissButton = { TextButton(onClick = { deletingStructure = null }) { Text("Отмена") } }
                    )
                }
                if (showAssetDialog) {
                    AssetDialog(editingAsset, branches, cabinets, workplaces, assetTypes,
                        onDismiss = { showAssetDialog = false },
                        onSave = { updated, moveReason, moveComment ->
                            lifecycleScope.launch {
                                try {
                                    val old = editingAsset
                                    if (old == null) {
                                        val newId = dao.addAsset(updated)
                                        dao.addMovement(Movement(
                                            assetId = newId, inventoryNumber = updated.inventoryNumber, assetName = updated.name,
                                            fromBranch = "", fromCabinet = "", fromWorkplace = "",
                                            toBranch = branches.firstOrNull { it.id == updated.branchId }?.name.orEmpty(),
                                            toCabinet = cabinets.firstOrNull { it.id == updated.cabinetId }?.name.orEmpty(),
                                            toWorkplace = workplaces.firstOrNull { it.id == updated.workplaceId }?.name.orEmpty(),
                                            movedAt = updated.updatedAt, reason = "Первичное размещение"
                                        ))
                                    } else {
                                        if (old.branchId != updated.branchId || old.cabinetId != updated.cabinetId || old.workplaceId != updated.workplaceId) {
                                            dao.addMovement(Movement(
                                                assetId = old.id, inventoryNumber = old.inventoryNumber, assetName = old.name,
                                                fromBranch = branches.firstOrNull { it.id == old.branchId }?.name.orEmpty(),
                                                fromCabinet = cabinets.firstOrNull { it.id == old.cabinetId }?.name.orEmpty(),
                                                fromWorkplace = workplaces.firstOrNull { it.id == old.workplaceId }?.name.orEmpty(),
                                                toBranch = branches.firstOrNull { it.id == updated.branchId }?.name.orEmpty(),
                                                toCabinet = cabinets.firstOrNull { it.id == updated.cabinetId }?.name.orEmpty(),
                                                toWorkplace = workplaces.firstOrNull { it.id == updated.workplaceId }?.name.orEmpty(),
                                                reason = moveReason.ifBlank { "Перемещение оборудования" }, comment = moveComment
                                            ))
                                        }
                                        dao.updateAsset(updated)
                                    }
                                    showAssetDialog = false
                                } catch (e: Exception) {
                                    Toast.makeText(this@MainActivity, "Не удалось сохранить. Проверь инвентарный номер: он должен быть уникальным.", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    private fun assetLocation(asset: Asset, branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>): String {
        return "${branches.firstOrNull { it.id == asset.branchId }?.name.orEmpty()} / ${cabinets.firstOrNull { it.id == asset.cabinetId }?.name.orEmpty()} / ${workplaces.firstOrNull { it.id == asset.workplaceId }?.name ?: "Общее имущество кабинета"}"
    }

    private fun shareFile(file: File, mime: String) {
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Поделиться файлом"))
    }
}

@Composable private fun PageHero(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = Color.Transparent, shadowElevation = 2.dp) {
        Row(
            Modifier.background(Brush.linearGradient(listOf(Color(0xFF126B78), Color(0xFF18A6A0), Color(0xFF287DA2))))
                .padding(horizontal = 16.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            Surface(shape = RoundedCornerShape(15.dp), color = Color(0x33FFFFFF), modifier = Modifier.size(46.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(25.dp)) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color(0xFFE0F7F5), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable private fun OverviewScreen(
    branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>,
    assets: List<Asset>, archivedCount: Int, movements: List<Movement>, audits: List<Audit>,
    onNavigate: (Int) -> Unit, onAddAsset: () -> Unit, onNewAudit: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(5.dp)
            ) {
                Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF126B78), Color(0xFF18A6A0), Color(0xFF287DA2)))).padding(horizontal = 22.dp, vertical = 24.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("KaenInventory", color = Color.White, style = MaterialTheme.typography.headlineSmall)
                        Text("Контроль имущества · сводка организации", color = Color(0xFFE2F8FF), style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Филиалы", branches.size, Icons.Filled.Apartment, Color(0xFF2387F5), Modifier.weight(1f)) { onNavigate(1) }
                StatCard("Кабинеты", cabinets.size, Icons.Filled.MeetingRoom, Color(0xFF9954E8), Modifier.weight(1f)) { onNavigate(1) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Рабочие места", workplaces.size, Icons.Filled.Chair, Color(0xFF25A94B), Modifier.weight(1f)) { onNavigate(1) }
                StatCard("Имущество", assets.size, Icons.Filled.Inventory2, Color(0xFFFF9D16), Modifier.weight(1f)) { onNavigate(2) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Перемещения", movements.size, Icons.Filled.SwapHoriz, Color(0xFF00AFC1), Modifier.weight(1f)) { onNavigate(5) }
                StatCard("В архиве", archivedCount, Icons.Filled.Archive, Color(0xFF24A65A), Modifier.weight(1f)) { onNavigate(4) }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Быстрые действия", style = MaterialTheme.typography.titleMedium, color = Color(0xFF163D59))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onAddAsset, modifier = Modifier.weight(1f)) { Text("＋ Добавить имущество") }
                        OutlinedButton(onClick = onNewAudit, modifier = Modifier.weight(1f)) { Text("Новая инвентаризация") }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(3.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.History, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(27.dp))
                        Text("Последние перемещения", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onNavigate(5) }) { Text("Все →") }
                    }
                    if (movements.isEmpty()) {
                        Text("Здесь появятся перемещения имущества", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    } else {
                        movements.take(5).forEachIndexed { index, movement ->
                            if (index > 0) HorizontalDivider(color = Color(0xFFE5EDF7))
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFFE6F2FF), modifier = Modifier.size(42.dp)) {
                                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Inventory2, contentDescription = null, tint = Color(0xFF1477D4), modifier = Modifier.size(23.dp)) }
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("${movement.assetName} · ${movement.inventoryNumber}", style = MaterialTheme.typography.titleSmall, maxLines = 1)
                                    Text("${movement.fromCabinet} → ${movement.toCabinet}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(SimpleDateFormat("dd.MM.yy", Locale("ru")).format(Date(movement.movedAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun StatCard(label: String, count: Int, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.heightIn(min = 112.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(shape = RoundedCornerShape(50), color = tint, modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(count.toString(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.headlineMedium)
                Text(label, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.labelLarge, maxLines = 2)
            }
        }
    }
}

private fun structureKindName(kind: String): String = when (kind) {
    "branch" -> "филиал"
    "cabinet" -> "кабинет"
    else -> "рабочее место"
}

@Composable private fun StructureScreen(
    branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>,
    assets: List<Asset>, assetTypes: List<AssetType>,
    onAdd: () -> Unit, onHistory: (String) -> Unit, onOpenAsset: (Asset) -> Unit,
    onEdit: (String, Long, String) -> Unit, onDelete: (String, Long, String) -> Unit
) {
    var headerExpanded by remember { mutableStateOf(false) }
    var filtersExpanded by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var branchFilter by remember { mutableLongStateOf(0L) }
    var cabinetFilter by remember { mutableLongStateOf(0L) }
    var branchMenu by remember { mutableStateOf(false) }
    var cabinetMenu by remember { mutableStateOf(false) }
    val visible = branches.filter { b ->
        (branchFilter == 0L || b.id == branchFilter) && (cabinetFilter == 0L || cabinets.any { it.id == cabinetFilter && it.branchId == b.id }) &&
        (query.isBlank() || b.name.contains(query, true) || cabinets.filter { it.branchId == b.id && (cabinetFilter == 0L || it.id == cabinetFilter) }.any { c ->
            c.name.contains(query, true) || workplaces.filter { it.cabinetId == c.id }.any { it.name.contains(query, true) } ||
                assets.any { it.cabinetId == c.id && (it.name.contains(query, true) || it.inventoryNumber.contains(query, true)) }
        })
    }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        // Компактная шапка раздела: меньше вертикального пространства, больше места дереву структуры.
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = Color.Transparent,
            shadowElevation = 1.dp
        ) {
            Row(
                Modifier.background(Brush.linearGradient(listOf(Color(0xFF126B78), Color(0xFF287DA2))))
                    .padding(horizontal = 13.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(shape = RoundedCornerShape(12.dp), color = Color(0x33FFFFFF), modifier = Modifier.size(38.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.AccountTree, null, tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(0.dp)) {
                    Text("Структура", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Филиалы · кабинеты · рабочие места", color = Color(0xFFE0F7F5), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(
                onClick = { filtersExpanded = true },
                modifier = Modifier.weight(1f).heightIn(min = 42.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)
            ) { Icon(Icons.Filled.FilterList, null); Spacer(Modifier.width(5.dp)); Text("Фильтры") }
            Button(
                onClick = onAdd,
                modifier = Modifier.weight(1f).heightIn(min = 42.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)
            ) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(5.dp)); Text("Добавить") }
        }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Color.White).padding(7.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            StructureMetric("Филиалы", branches.size, Modifier.weight(1f))
            StructureMetric("Кабинеты", cabinets.size, Modifier.weight(1f))
            StructureMetric("Места", workplaces.size, Modifier.weight(1f))
        }
        if (filtersExpanded) ModalBottomSheet(onDismissRequest = { filtersExpanded = false }, containerColor = Color.White, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Фильтры структуры", style = MaterialTheme.typography.titleLarge, color = Color(0xFF123B5A))
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { branchMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(branches.firstOrNull { it.id == branchFilter }?.name ?: "Все филиалы", modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(branchMenu, { branchMenu = false }) {
                        DropdownMenuItem(text = { Text("Все филиалы") }, onClick = { branchFilter = 0L; cabinetFilter = 0L; branchMenu = false })
                        branches.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { branchFilter = b.id; cabinetFilter = 0L; branchMenu = false }) }
                    }
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { cabinetMenu = true }, modifier = Modifier.fillMaxWidth(), enabled = branchFilter != 0L) { Text(cabinets.firstOrNull { it.id == cabinetFilter }?.name ?: "Все кабинеты", modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(cabinetMenu, { cabinetMenu = false }) {
                        DropdownMenuItem(text = { Text("Все кабинеты") }, onClick = { cabinetFilter = 0L; cabinetMenu = false })
                        cabinets.filter { branchFilter == 0L || it.branchId == branchFilter }.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { cabinetFilter = c.id; cabinetMenu = false }) }
                    }
                }
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Поиск по структуре") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { branchFilter = 0L; cabinetFilter = 0L; query = ""; filtersExpanded = false }, modifier = Modifier.weight(1f)) { Text("Сбросить") }
                    Button(onClick = { filtersExpanded = false }, modifier = Modifier.weight(1f)) { Text("Применить") }
                }
            }
        }
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().heightIn(min = 48.dp), textStyle = MaterialTheme.typography.bodySmall, singleLine = true, leadingIcon = { Icon(Icons.Filled.Search, null, modifier=Modifier.size(19.dp)) }, placeholder = { Text("Поиск филиала, кабинета, места или имущества", style=MaterialTheme.typography.labelSmall) })
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(visible, key = { "b${it.id}" }) { branch ->
                var expanded by remember(branch.id) { mutableStateOf(false) }
                val branchCabinets = cabinets.filter { it.branchId == branch.id && (cabinetFilter == 0L || it.id == cabinetFilter) }
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFE6F3FA), modifier = Modifier.size(42.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Apartment, null, tint = Color(0xFF087E9A)) } }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) { Text(branch.name, style = MaterialTheme.typography.titleMedium, color = Color(0xFF163D59)); Text("${branchCabinets.size} кабинетов · ${branchCabinets.sumOf { c -> workplaces.count { it.cabinetId == c.id } }} рабочих мест", style = MaterialTheme.typography.labelSmall, color = Color(0xFF728596)) }
                            IconButton(onClick = { expanded = !expanded }) { Text(if (expanded) "⌃" else "⌄") }
                            Box { var menu by remember { mutableStateOf(false) }; IconButton(onClick = { menu = true }) { Text("⋮") }; DropdownMenu(menu, { menu = false }) { DropdownMenuItem(text = { Text("Изменить") }, onClick = { menu = false; onEdit("branch", branch.id, branch.name) }); DropdownMenuItem(text = { Text("Удалить") }, onClick = { menu = false; onDelete("branch", branch.id, branch.name) }) } }
                        }
                        if (expanded) branchCabinets.forEach { cabinet ->
                            var cabinetExpanded by remember(cabinet.id) { mutableStateOf(false) }
                            val ws = workplaces.filter { it.cabinetId == cabinet.id }
                            val cabinetAssets = assets.filter { it.cabinetId == cabinet.id && it.workplaceId == null }
                            Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFFF3F8FC)) {
                                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.MeetingRoom, null, tint = Color(0xFF2587A0), modifier = Modifier.size(19.dp)); Spacer(Modifier.width(7.dp));
                                        Text(cabinet.name, Modifier.weight(1f).clickable { cabinetExpanded = !cabinetExpanded }, style = MaterialTheme.typography.titleSmall)
                                        Text("${cabinetAssets.size + ws.sumOf { w -> assets.count { it.workplaceId == w.id } }}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF718596))
                                        IconButton(onClick = { cabinetExpanded = !cabinetExpanded }) { Text(if (cabinetExpanded) "⌃" else "⌄") }
                                        TextButton(onClick = { onHistory(cabinet.name) }) { Text("История") }
                                        Box { var menu by remember { mutableStateOf(false) }; IconButton(onClick = { menu = true }) { Text("⋮") }; DropdownMenu(menu, { menu = false }) { DropdownMenuItem(text = { Text("Изменить") }, onClick = { menu = false; onEdit("cabinet", cabinet.id, cabinet.name) }); DropdownMenuItem(text = { Text("Удалить") }, onClick = { menu = false; onDelete("cabinet", cabinet.id, cabinet.name) }) } }
                                    }
                                    if (cabinetExpanded) {
                                        if (cabinetAssets.isNotEmpty()) {
                                            Text("Общее имущество кабинета", style = MaterialTheme.typography.labelSmall, color = Color(0xFF718596), modifier = Modifier.padding(start = 7.dp, top = 3.dp))
                                            cabinetAssets.forEach { asset -> StructureAssetRow(asset, assetTypes, onOpenAsset) }
                                        }
                                        ws.forEach { workplace ->
                                            val workplaceAssets = assets.filter { it.workplaceId == workplace.id }
                                            Row(Modifier.fillMaxWidth().padding(start = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Filled.Chair, null, tint = Color(0xFF7292A5), modifier = Modifier.size(17.dp))
                                                Text(workplace.name, Modifier.weight(1f).clickable { onHistory(workplace.name) }.padding(8.dp), style = MaterialTheme.typography.bodyMedium)
                                                Text("${workplaceAssets.size}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF718596))
                                                IconButton(onClick = { onEdit("workplace", workplace.id, workplace.name) }) { Text("✎") }
                                                IconButton(onClick = { onDelete("workplace", workplace.id, workplace.name) }) { Text("×", color = MaterialTheme.colorScheme.error) }
                                            }
                                            workplaceAssets.forEach { asset -> StructureAssetRow(asset, assetTypes, onOpenAsset) }
                                            if (workplaceAssets.isEmpty()) Text("Нет имущества", Modifier.padding(start = 31.dp, bottom = 4.dp), style = MaterialTheme.typography.labelSmall, color = Color(0xFF9AAAB6))
                                        }
                                        if (ws.isEmpty() && cabinetAssets.isEmpty()) Text("Нет рабочих мест и имущества", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8093A2))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (visible.isEmpty()) item { EmptyState("Ничего не найдено", "Измените поисковый запрос") }
        }
    }
}

@Composable private fun StructureAssetRow(asset: Asset, assetTypes: List<AssetType>, onClick: (Asset) -> Unit) {
    val icon = typeIcon(assetTypes.firstOrNull { it.name == asset.type }?.iconKey ?: "devices")
    Row(
        Modifier.fillMaxWidth().padding(start = 27.dp, end = 5.dp, top = 2.dp, bottom = 2.dp)
            .clip(RoundedCornerShape(8.dp)).background(Color.White).clickable { onClick(asset) }.padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.width(9.dp))
        Text(asset.name, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
        Text(asset.inventoryNumber, style = MaterialTheme.typography.labelSmall, color = Color(0xFF718596), maxLines = 1)
    }
}

@Composable private fun StructureMetric(label: String, value: Int, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(12.dp), color = Color(0xFFF0F7FB)) { Column(Modifier.padding(horizontal=7.dp, vertical=4.dp)) { Text(value.toString(), style = MaterialTheme.typography.titleSmall, color = Color(0xFF087E9A)); Text(label, style = MaterialTheme.typography.labelSmall, color = Color(0xFF718596), maxLines=1) } }
}

@Composable private fun EmptyState(title: String, subtitle: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("⌕", style = MaterialTheme.typography.headlineLarge, color = Color(0xFF65A6B7)); Text(title, style = MaterialTheme.typography.titleMedium); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596)) } }
}

@Composable private fun AssetDetailRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color(0xFF71858D))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF183B4A))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE8EFF1)))
    }
}

@Composable private fun AssetsScreen(
    assets: List<Asset>, branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>, assetTypes: List<AssetType>,
    search: String, onSearch: (String) -> Unit, branchFilter: Long, onBranchFilter: (Long) -> Unit,
    cabinetFilter: Long, onCabinetFilter: (Long) -> Unit, workplaceFilter: Long, onWorkplaceFilter: (Long) -> Unit,
    conditionFilter: String, onConditionFilter: (String) -> Unit, onReset: () -> Unit,
    onAdd: () -> Unit, onEdit: (Asset) -> Unit, onOpenAsset: (Asset) -> Unit, onArchive: (Asset) -> Unit, onHistory: (Asset) -> Unit
) {
    var filtersExpanded by remember { mutableStateOf(false) }
    var menu by remember { mutableIntStateOf(0) }
    val activeFilters = listOf(branchFilter != 0L, cabinetFilter != 0L, workplaceFilter != 0L, conditionFilter != "Все состояния").count { it }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PageHero("Имущество", "Каталог оборудования и техники · ${assets.size} объектов", Icons.Filled.Inventory2)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAdd, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Добавить") }
            FilledTonalButton(onClick = { filtersExpanded = true }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.FilterList, null); Spacer(Modifier.width(5.dp)); Text("Фильтры${if (activeFilters > 0) " · $activeFilters" else ""}")
            }
        }
        OutlinedTextField(search, onSearch, label = { Text("Инв. №, серийный № или название") }, modifier = Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(16.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 14.dp)) {
            items(assets, key = { it.id }) { asset ->
                val branch = branches.firstOrNull { it.id == asset.branchId }?.name.orEmpty()
                val cabinet = cabinets.firstOrNull { it.id == asset.cabinetId }?.name.orEmpty()
                val workplace = workplaces.firstOrNull { it.id == asset.workplaceId }?.name ?: "Общее имущество кабинета"
                val photo = assetPhotoPaths(asset.photoPath).firstOrNull()
                Card(Modifier.fillMaxWidth().clickable { onOpenAsset(asset) }, shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                        if (photo != null) AssetPhoto(photo, Modifier.size(66.dp).clip(RoundedCornerShape(13.dp))) { PhotoPlaceholder(Modifier.size(66.dp)) }
                        else Surface(Modifier.size(66.dp), shape = RoundedCornerShape(13.dp), color = Color(0xFFE7F3F6)) { Box(contentAlignment = Alignment.Center) { Text(typeIcon(assetTypes.firstOrNull { it.name == asset.type }?.iconKey ?: "devices"), style = MaterialTheme.typography.headlineMedium) } }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(asset.name, style = MaterialTheme.typography.titleSmall, color = Color(0xFF163D59), maxLines = 2)
                            Text("${asset.inventoryNumber} · ${asset.type}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF087E9A), maxLines = 1)
                            Text("$branch · $cabinet · $workplace", style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596), maxLines = 2)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = RoundedCornerShape(50), color = if (asset.condition.equals("Исправно", true)) Color(0xFFE8F6EF) else Color(0xFFFFF3E5)) {
                                    Text(asset.condition, Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, color = Color(0xFF356B50))
                                }
                                TextButton(onClick = { onEdit(asset) }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) { Text("Изменить") }
                                TextButton(onClick = { onHistory(asset) }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) { Text("История") }
                            }
                        }
                    }
                }
            }
            if (assets.isEmpty()) item { EmptyState("Имущество не найдено", "Добавьте объект или измените условия поиска") }
        }
    }
    if (filtersExpanded) {
        ModalBottomSheet(onDismissRequest = { filtersExpanded = false }, containerColor = Color.White, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Фильтры имущества", style = MaterialTheme.typography.titleLarge, color = Color(0xFF123B5A))
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { menu = 1 }, modifier = Modifier.fillMaxWidth()) { Text(branches.firstOrNull { it.id == branchFilter }?.name ?: "Все филиалы", modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(menu == 1, { menu = 0 }) {
                        DropdownMenuItem(text = { Text("Все филиалы") }, onClick = { onBranchFilter(0L); onCabinetFilter(0L); onWorkplaceFilter(0L); menu = 0 })
                        branches.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { onBranchFilter(b.id); menu = 0 }) }
                    }
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { menu = 2 }, modifier = Modifier.fillMaxWidth()) { Text(cabinets.firstOrNull { it.id == cabinetFilter }?.name ?: "Все кабинеты", modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(menu == 2, { menu = 0 }) {
                        DropdownMenuItem(text = { Text("Все кабинеты") }, onClick = { onCabinetFilter(0L); onWorkplaceFilter(0L); menu = 0 })
                        cabinets.filter { branchFilter == 0L || it.branchId == branchFilter }.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { onCabinetFilter(c.id); onWorkplaceFilter(0L); menu = 0 }) }
                    }
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { menu = 3 }, modifier = Modifier.fillMaxWidth()) { Text(workplaces.firstOrNull { it.id == workplaceFilter }?.name ?: "Все рабочие места", modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(menu == 3, { menu = 0 }) {
                        DropdownMenuItem(text = { Text("Все рабочие места") }, onClick = { onWorkplaceFilter(0L); menu = 0 })
                        workplaces.filter { cabinetFilter == 0L || it.cabinetId == cabinetFilter }.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { onWorkplaceFilter(w.id); menu = 0 }) }
                    }
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { menu = 4 }, modifier = Modifier.fillMaxWidth()) { Text(conditionFilter, modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(menu == 4, { menu = 0 }) { listOf("Все состояния", "Исправно", "Неисправно", "Требует проверки", "Списано").forEach { state -> DropdownMenuItem(text = { Text(state) }, onClick = { onConditionFilter(state); menu = 0 }) } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onReset(); filtersExpanded = false }, modifier = Modifier.weight(1f)) { Text("Сбросить") }
                    Button(onClick = { filtersExpanded = false }, modifier = Modifier.weight(1f)) { Text("Показать ${assets.size}") }
                }
            }
        }
    }
}

@Composable private fun ColumnScope.AuditsScreen(
    audits: List<Audit>, branches: List<Branch>, cabinets: List<Cabinet>, selectedAuditId: Long?, auditBranchId: Long,
    onBranch: (Long) -> Unit, onSelect: (Long) -> Unit, onStart: () -> Unit, dao: InventoryDao,
    scannedNumber: String, onClearScannedNumber: () -> Unit, onScan: () -> Unit,
    onExport: (Long, List<AuditItem>) -> Unit, onComplete: (Long) -> Unit, onSetStatus: (AuditItem, String) -> Unit
) {
    var headerExpanded by remember { mutableStateOf(false) }
    var branchMenu by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var detailsExpanded by remember { mutableStateOf(false) }
    var locationFiltersExpanded by remember { mutableStateOf(false) }
    var auditBranchFilter by remember(selectedAuditId) { mutableLongStateOf(0L) }
    var auditCabinetFilter by remember(selectedAuditId) { mutableLongStateOf(0L) }
    var statusFilter by remember(selectedAuditId) { mutableStateOf("Все") }
    var itemQuery by remember(selectedAuditId) { mutableStateOf("") }
    var locationMenu by remember { mutableIntStateOf(0) }
    val selected = audits.firstOrNull { it.id == selectedAuditId }
    val visibleAudits = audits.filter { query.isBlank() || it.title.contains(query, true) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(if (selectedAuditId == null) 10.dp else 5.dp)) {
        if (selectedAuditId == null) {
            PageHero("Проверки", "Инвентаризации и контроль наличия", Icons.Filled.FactCheck)
            Button(onClick = { headerExpanded = !headerExpanded }, modifier = Modifier.fillMaxWidth()) { Text(if (headerExpanded) "Скрыть создание проверки" else "＋ Новая инвентаризация") }
            if (headerExpanded) Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Область инвентаризации", style = MaterialTheme.typography.labelLarge)
                    Box {
                        OutlinedButton(onClick = { branchMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(branches.firstOrNull { it.id == auditBranchId }?.name ?: "Вся организация") }
                        DropdownMenu(branchMenu, { branchMenu = false }) {
                            DropdownMenuItem(text = { Text("Вся организация") }, onClick = { onBranch(0); branchMenu = false })
                            branches.forEach { branch -> DropdownMenuItem(text = { Text(branch.name) }, onClick = { onBranch(branch.id); branchMenu = false }) }
                        }
                    }
                    Button(onClick = { onStart(); headerExpanded = false }, modifier = Modifier.fillMaxWidth()) { Text("＋ Начать новую инвентаризацию") }
                }
            }
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Filled.Search, null) }, placeholder = { Text("Найти проверку") })
        }
        if (selectedAuditId == null) {
            Text("История проверок · ${visibleAudits.size}", style = MaterialTheme.typography.titleSmall, color = Color(0xFF476477))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 14.dp)) {
                items(visibleAudits, key = { it.id }) { audit ->
                    val isDone = audit.completedAt != null
                    Card(Modifier.fillMaxWidth().clickable { onSelect(audit.id) }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(13.dp), color = if (isDone) Color(0xFFE6F5ED) else Color(0xFFFFF4DF), modifier = Modifier.size(46.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.FactCheck, null, tint = if (isDone) Color(0xFF27865B) else Color(0xFFB77B18)) } }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(audit.title, style = MaterialTheme.typography.titleSmall, color = Color(0xFF163D59))
                                Text("${dateText(audit.startedAt)} · ${if (isDone) "Завершена" else "В процессе"}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596))
                            }
                            Text("›", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF16869B))
                        }
                    }
                }
                if (visibleAudits.isEmpty()) item { EmptyState("Проверок пока нет", "Создайте новую инвентаризацию") }
            }
        } else {
            var compareAuditId by remember(selectedAuditId) { mutableStateOf<Long?>(null) }
            var compareMenu by remember { mutableStateOf(false) }
            val rows by dao.auditItems(selectedAuditId).collectAsStateWithLifecycle(emptyList())
            var correctedScan by remember(scannedNumber) { mutableStateOf(scannedNumber) }
            var scanNotFound by remember { mutableStateOf(false) }
            var scanAlreadyFound by remember { mutableStateOf(false) }
            val previousRows by dao.auditItems(compareAuditId ?: selectedAuditId).collectAsStateWithLifecycle(emptyList())
            val found = rows.count { it.status == "Найдено" }
            val missing = rows.count { it.status == "Не найдено" }
            val pending = rows.count { it.status == "Ожидает проверки" || it.status == "Требует проверки" }
            val progress = if (rows.isEmpty()) 0f else (found + missing).toFloat() / rows.size
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onSelect(-1L) }) { Text("‹ Все проверки") }
                Spacer(Modifier.weight(1f))
                Text(if (selected?.completedAt == null) "В процессе" else "Завершена", color = if (selected?.completedAt == null) Color(0xFFB77B18) else Color(0xFF27865B), style = MaterialTheme.typography.labelLarge)
            }
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(selected?.title ?: "Инвентаризация", style = MaterialTheme.typography.titleSmall, color = Color(0xFF163D59), maxLines = 1)
                            Text("${found} найдено · ${missing} не найдено · ${pending} ожидает · ${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = Color(0xFF526F80))
                        }
                        TextButton(onClick = { detailsExpanded = !detailsExpanded }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) { Text(if (detailsExpanded) "Свернуть" else "Подробнее") }
                    }
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    if (detailsExpanded) {
                        Text("Начата: ${selected?.let { dateText(it.startedAt) } ?: "—"}${selected?.completedAt?.let { " · Завершена: ${dateText(it)}" } ?: ""}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF718596))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AuditMetric("Найдено", found, Color(0xFFE7F5ED), Modifier.weight(1f))
                            AuditMetric("Не найдено", missing, Color(0xFFFFEDEC), Modifier.weight(1f))
                            AuditMetric("Ожидает", pending, Color(0xFFFFF4DF), Modifier.weight(1f))
                        }
                        Text("Распределение результатов", style = MaterialTheme.typography.labelMedium, color = Color(0xFF526F80))
                        Row(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)).background(Color(0xFFE9EFF2)), horizontalArrangement = Arrangement.Start) {
                            if (found > 0) Box(Modifier.weight(found.toFloat()).fillMaxHeight().background(Color(0xFF36A875)))
                            if (missing > 0) Box(Modifier.weight(missing.toFloat()).fillMaxHeight().background(Color(0xFFE06B62)))
                            if (pending > 0) Box(Modifier.weight(pending.toFloat()).fillMaxHeight().background(Color(0xFFE7B24D)))
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Список · ${rows.size}", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                if (selected?.completedAt == null) TextButton(onClick = onScan, contentPadding = PaddingValues(horizontal = 5.dp)) { Icon(Icons.Filled.CameraAlt, null); Text("Сканировать") }
                TextButton(onClick = { locationFiltersExpanded = true }) { Icon(Icons.Filled.FilterList, null); Spacer(Modifier.width(4.dp)); Text("Фильтры") }
                Box { OutlinedButton(onClick = { compareMenu = true }) { Text("Сравнить") }; DropdownMenu(compareMenu, { compareMenu = false }) { audits.filter { it.id != selectedAuditId }.forEach { old -> DropdownMenuItem(text = { Text(old.title) }, onClick = { compareAuditId = old.id; compareMenu = false }) } } }
            }
            if (locationFiltersExpanded) ModalBottomSheet(onDismissRequest = { locationFiltersExpanded = false }, containerColor = Color.White, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Фильтры проверки", style = MaterialTheme.typography.titleLarge, color = Color(0xFF123B5A))
                    OutlinedTextField(itemQuery, { itemQuery = it }, Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Filled.Search, null) }, placeholder = { Text("Поиск по названию или инв. номеру") })
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { locationMenu = 1 }, modifier = Modifier.fillMaxWidth()) { Text(branches.firstOrNull { it.id == auditBranchFilter }?.name ?: "Все филиалы", modifier = Modifier.weight(1f)); Text("⌄") }
                        DropdownMenu(locationMenu == 1, { locationMenu = 0 }) {
                            DropdownMenuItem(text = { Text("Все филиалы") }, onClick = { auditBranchFilter = 0L; auditCabinetFilter = 0L; locationMenu = 0 })
                            branches.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { auditBranchFilter = b.id; auditCabinetFilter = 0L; locationMenu = 0 }) }
                        }
                    }
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { locationMenu = 2 }, modifier = Modifier.fillMaxWidth()) { Text(cabinets.firstOrNull { it.id == auditCabinetFilter }?.name ?: "Все кабинеты", modifier = Modifier.weight(1f)); Text("⌄") }
                        DropdownMenu(locationMenu == 2, { locationMenu = 0 }) {
                            DropdownMenuItem(text = { Text("Все кабинеты") }, onClick = { auditCabinetFilter = 0L; locationMenu = 0 })
                            cabinets.filter { auditBranchFilter == 0L || it.branchId == auditBranchFilter }.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { auditBranchFilter = c.branchId; auditCabinetFilter = c.id; locationMenu = 0 }) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf("Все", "Найдено", "Не найдено", "Ожидает").forEach { state -> FilterChip(selected = statusFilter == state, onClick = { statusFilter = state }, label = { Text(state) }) }
                    }
                    Button(onClick = { locationFiltersExpanded = false }, modifier = Modifier.fillMaxWidth()) { Text("Применить фильтры") }
                }
            }
            if (compareAuditId != null) {
                val currentMap = rows.associateBy { it.inventoryNumber }; val previousMap = previousRows.associateBy { it.inventoryNumber }
                val added = currentMap.keys - previousMap.keys
                val absent = currentMap.values.count { it.status == "Не найдено" }
                val moved = currentMap.keys.intersect(previousMap.keys).count { currentMap[it]?.expectedLocation != previousMap[it]?.expectedLocation }
                Text("Новое: ${added.size} · Не найдено: $absent · Изменено место: $moved", style = MaterialTheme.typography.bodySmall, color = Color(0xFF476477))
            }
            val filteredRows = rows.filter { row ->
                val branchName = branches.firstOrNull { it.id == auditBranchFilter }?.name
                val cabinetName = cabinets.firstOrNull { it.id == auditCabinetFilter }?.name
                val locationMatch = (branchName == null || row.expectedLocation.startsWith("$branchName /")) &&
                    (cabinetName == null || row.expectedLocation.contains(" / $cabinetName /"))
                val stateMatch = when (statusFilter) {
                    "Найдено" -> row.status == "Найдено"
                    "Не найдено" -> row.status == "Не найдено"
                    "Ожидает" -> row.status == "Ожидает проверки" || row.status == "Требует проверки"
                    else -> true
                }
                val textMatch = itemQuery.isBlank() || row.assetName.contains(itemQuery, true) || row.inventoryNumber.contains(itemQuery, true)
                locationMatch && stateMatch && textMatch
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp), contentPadding = PaddingValues(bottom = 4.dp)) {
                items(filteredRows, key = { it.id }) { row ->
                    val isMissing = row.status == "Не найдено"
                    Card(shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(row.assetName, style = MaterialTheme.typography.titleSmall); Text("Инв. № ${row.inventoryNumber}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF718596)) }; Surface(shape = RoundedCornerShape(20.dp), color = when(row.status) { "Найдено" -> Color(0xFFE6F5ED); "Не найдено" -> Color(0xFFFFEDEC); else -> Color(0xFFFFF4DF) }) { Text(row.status, Modifier.padding(horizontal = 9.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall) } }
                            Text("Место: ${row.expectedLocation}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF647D8D), maxLines = 2)
                            if (isMissing) Text("Позиция отсутствует — требуется проверка местоположения", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB44B45))
                            if (selected?.completedAt == null) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = { onSetStatus(row, "Найдено") }) { Text("✓ Найдено") }
                                TextButton(onClick = { onSetStatus(row, "Не найдено") }) { Text("Не найдено") }
                                TextButton(onClick = { onSetStatus(row, "Требует проверки") }) { Text("Позже") }
                            }
                        }
                    }
                }
                if (filteredRows.isEmpty()) item { EmptyState("Ничего не найдено", "Измените фильтры или поисковый запрос") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (selected?.completedAt == null) Button(onClick = { onComplete(selectedAuditId) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) { Text("Завершить") }
                OutlinedButton(onClick = { onExport(selectedAuditId, rows) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) { Text("Экспорт Excel") }
            }
            if (scannedNumber.isNotBlank()) AlertDialog(
                onDismissRequest = onClearScannedNumber,
                title = { Text("Проверка распознанного номера") },
                text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Сверьте номер с наклейкой или надписью. При необходимости исправьте его вручную.")
                    OutlinedTextField(correctedScan, { correctedScan = it; scanNotFound = false; scanAlreadyFound = false }, label = { Text("Инвентарный номер") }, singleLine = true)
                    if (scanAlreadyFound) Text("Этот объект уже отмечен как найденный в текущей проверке.", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    if (scanNotFound) Text("Такой номер не найден в текущей инвентаризации. Исправьте номер или отметьте объект вручную.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                } },
                confirmButton = { Button(onClick = {
                    val match = rows.firstOrNull { it.inventoryNumber.trim().equals(correctedScan.trim(), true) }
                    if (match == null) scanNotFound = true else if (match.status == "Найдено") scanAlreadyFound = true else { onSetStatus(match, "Найдено"); onClearScannedNumber() }
                }, enabled = correctedScan.isNotBlank()) { Text("Подтвердить найдено") } },
                dismissButton = { TextButton(onClick = onClearScannedNumber) { Text("Закрыть") } }
            )
        }
    }
}

@Composable private fun AuditMetric(label: String, value: Int, tint: Color, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(13.dp), color = tint) { Column(Modifier.padding(10.dp)) { Text(value.toString(), style = MaterialTheme.typography.titleLarge, color = Color(0xFF173F57)); Text(label, style = MaterialTheme.typography.labelSmall, color = Color(0xFF5E7482)) } }
}

@Composable private fun MovementsScreen(
    movements: List<Movement>, branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>,
    query: String, onQuery: (String) -> Unit, onExport: (List<Movement>) -> Unit
) {
    var dateFrom by remember { mutableStateOf("") }
    var dateTo by remember { mutableStateOf("") }
    var branch by remember { mutableStateOf("Все филиалы") }
    var cabinet by remember { mutableStateOf("Все кабинеты") }
    var workplace by remember { mutableStateOf("Все рабочие места") }
    var operation by remember { mutableStateOf("Все операции") }
    var filtersExpanded by remember { mutableStateOf(false) }
    var menu by remember { mutableIntStateOf(0) }
    val parser = remember { SimpleDateFormat("dd.MM.yyyy", Locale("ru")) }
    val from = remember(dateFrom) { runCatching { parser.parse(dateFrom)?.time }.getOrNull() }
    val to = remember(dateTo) { runCatching { parser.parse(dateTo)?.time?.plus(86_399_999L) }.getOrNull() }
    val filtered = movements.filter { m ->
        val textMatch = query.isBlank() || listOf(m.inventoryNumber, m.assetName, m.fromBranch, m.fromCabinet, m.fromWorkplace, m.toBranch, m.toCabinet, m.toWorkplace).any { it.contains(query, true) }
        val opMatch = when (operation) {
            "Перемещение" -> m.reason.contains("Перемещ", true)
            "Архивирование" -> m.reason.contains("Архив", true)
            "Восстановление" -> m.reason.contains("Восстанов", true)
            "Обслуживание" -> m.reason.contains("Обслужив", true)
            "Изменение состояния" -> m.reason.contains("Изменение состояния", true)
            else -> true
        }
        textMatch && (from == null || m.movedAt >= from) && (to == null || m.movedAt <= to) &&
            (branch == "Все филиалы" || m.fromBranch == branch || m.toBranch == branch) &&
            (cabinet == "Все кабинеты" || m.fromCabinet == cabinet || m.toCabinet == cabinet) &&
            (workplace == "Все рабочие места" || m.fromWorkplace == workplace || m.toWorkplace == workplace) && opMatch
    }.sortedByDescending { it.movedAt }
    val grouped = filtered.groupBy { SimpleDateFormat("dd MMMM yyyy", Locale("ru")).format(Date(it.movedAt)).replaceFirstChar { c -> c.uppercase(Locale("ru")) } }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PageHero("История", "Журнал операций · ${filtered.size} событий", Icons.Filled.History)
        FilledTonalButton(onClick = { filtersExpanded = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.FilterList, null); Spacer(Modifier.width(5.dp)); Text("Фильтры и период") }
        OutlinedTextField(query, onQuery, Modifier.fillMaxWidth(), label = { Text("Поиск по инв. №, названию или месту") }, singleLine = true, leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(15.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("${filtered.size} операций", style = MaterialTheme.typography.labelMedium, color = Color(0xFF087E9A))
            TextButton(onClick = { onExport(filtered) }) { Text("Экспорт Excel") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            grouped.forEach { (day, entries) ->
                item(key = "day_$day") { Text(day, Modifier.padding(top = 5.dp, bottom = 1.dp), style = MaterialTheme.typography.titleSmall, color = Color(0xFF52717A)) }
                items(entries, key = { it.id }) { m ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(m.assetName, style = MaterialTheme.typography.titleSmall, color = Color(0xFF163D59), maxLines = 2)
                                    Text("Инв. № ${m.inventoryNumber}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF087E9A))
                                }
                                Text(SimpleDateFormat("HH:mm", Locale("ru")).format(Date(m.movedAt)), style = MaterialTheme.typography.labelMedium, color = Color(0xFF718596))
                            }
                            Text("${listOf(m.fromBranch, m.fromCabinet, m.fromWorkplace).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "—" }}  →  ${listOf(m.toBranch, m.toCabinet, m.toWorkplace).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF526F80))
                            if (m.reason.isNotBlank()) Text(m.reason, style = MaterialTheme.typography.labelMedium, color = Color(0xFF087E9A))
                            if (m.comment.isNotBlank()) Text(m.comment, style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596))
                        }
                    }
                }
            }
            if (filtered.isEmpty()) item { EmptyState("Операций не найдено", "Измените поиск или параметры фильтрации") }
        }
    }
    if (filtersExpanded) ModalBottomSheet(onDismissRequest = { filtersExpanded = false }, containerColor = Color.White, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Фильтры истории", style = MaterialTheme.typography.titleLarge, color = Color(0xFF123B5A))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(dateFrom, { dateFrom = it }, Modifier.weight(1f), label = { Text("Дата с") }, placeholder = { Text("ДД.ММ.ГГГГ") }, singleLine = true)
                OutlinedTextField(dateTo, { dateTo = it }, Modifier.weight(1f), label = { Text("Дата по") }, placeholder = { Text("ДД.ММ.ГГГГ") }, singleLine = true)
            }
            Box(Modifier.fillMaxWidth()) { OutlinedButton(onClick = { menu = 1 }, Modifier.fillMaxWidth()) { Text(branch, Modifier.weight(1f)); Text("⌄") }; DropdownMenu(menu == 1, { menu = 0 }) { DropdownMenuItem(text = { Text("Все филиалы") }, onClick = { branch = "Все филиалы"; cabinet = "Все кабинеты"; workplace = "Все рабочие места"; menu = 0 }); branches.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { branch = b.name; cabinet = "Все кабинеты"; workplace = "Все рабочие места"; menu = 0 }) } } }
            Box(Modifier.fillMaxWidth()) { OutlinedButton(onClick = { menu = 2 }, Modifier.fillMaxWidth()) { Text(cabinet, Modifier.weight(1f)); Text("⌄") }; DropdownMenu(menu == 2, { menu = 0 }) { DropdownMenuItem(text = { Text("Все кабинеты") }, onClick = { cabinet = "Все кабинеты"; workplace = "Все рабочие места"; menu = 0 }); cabinets.filter { branch == "Все филиалы" || branches.firstOrNull { b -> b.id == it.branchId }?.name == branch }.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { cabinet = c.name; workplace = "Все рабочие места"; menu = 0 }) } } }
            Box(Modifier.fillMaxWidth()) { OutlinedButton(onClick = { menu = 3 }, Modifier.fillMaxWidth()) { Text(workplace, Modifier.weight(1f)); Text("⌄") }; DropdownMenu(menu == 3, { menu = 0 }) { DropdownMenuItem(text = { Text("Все рабочие места") }, onClick = { workplace = "Все рабочие места"; menu = 0 }); workplaces.filter { cabinet == "Все кабинеты" || cabinets.firstOrNull { c -> c.id == it.cabinetId }?.name == cabinet }.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { workplace = w.name; menu = 0 }) } } }
            Box(Modifier.fillMaxWidth()) { OutlinedButton(onClick = { menu = 4 }, Modifier.fillMaxWidth()) { Text(operation, Modifier.weight(1f)); Text("⌄") }; DropdownMenu(menu == 4, { menu = 0 }) { listOf("Все операции", "Перемещение", "Обслуживание", "Изменение состояния", "Архивирование", "Восстановление").forEach { op -> DropdownMenuItem(text = { Text(op) }, onClick = { operation = op; menu = 0 }) } } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { dateFrom = ""; dateTo = ""; branch = "Все филиалы"; cabinet = "Все кабинеты"; workplace = "Все рабочие места"; operation = "Все операции"; onQuery(""); filtersExpanded = false }, Modifier.weight(1f)) { Text("Сбросить") }
                Button(onClick = { filtersExpanded = false }, Modifier.weight(1f)) { Text("Применить") }
            }
        }
    }
}

@Composable private fun MoreScreen(movements: List<Movement>, assetTypes: List<AssetType>, branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>, onAddType:(String,String)->Unit, onUpdateType:(AssetType)->Unit, onDeleteType:(Long)->Unit, onClearTestData:()->Unit, historyFilter: String, onHistoryFilter: (String) -> Unit, onExportXlsx: () -> Unit, onExportHistoryXlsx: (List<Movement>) -> Unit, onExportPdf: () -> Unit, onBackup: () -> Unit, onRestore: () -> Unit, onImportExcel: () -> Unit) {
    var showHistoryExport by remember { mutableStateOf(false) }
    var showBackupWindow by remember { mutableStateOf(false) }
    var showTypeWindow by remember { mutableStateOf(false) }
    var showCharacteristicsWindow by remember { mutableStateOf(false) }
    var dateFrom by remember { mutableStateOf("") }
    var dateTo by remember { mutableStateOf("") }
    var historyBranch by remember { mutableStateOf("Все филиалы") }
    var historyCabinet by remember { mutableStateOf("Все кабинеты") }
    var historyWorkplace by remember { mutableStateOf("Все рабочие места") }
    var historyOperation by remember { mutableStateOf("Все операции") }
    var historyMenu by remember { mutableIntStateOf(0) }
    val parser = remember { java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale("ru")) }
    val fromMillis = remember(dateFrom) { runCatching { parser.parse(dateFrom)?.time }.getOrNull() }
    val toMillis = remember(dateTo) { runCatching { parser.parse(dateTo)?.time?.plus(86_399_999L) }.getOrNull() }
    val dateRangeValid = (dateFrom.isBlank() || fromMillis != null) && (dateTo.isBlank() || toMillis != null) && (fromMillis == null || toMillis == null || fromMillis <= toMillis)
    val visibleMovements = movements.filter { movement ->
        val matchesText = historyFilter.isBlank() || listOf(movement.inventoryNumber, movement.assetName, movement.fromBranch, movement.fromCabinet, movement.fromWorkplace, movement.toBranch, movement.toCabinet, movement.toWorkplace).any { it.contains(historyFilter, true) }
        val matchesFrom = fromMillis == null || movement.movedAt >= fromMillis
        val matchesTo = toMillis == null || movement.movedAt <= toMillis
        val matchesBranch = historyBranch == "Все филиалы" || movement.fromBranch == historyBranch || movement.toBranch == historyBranch
        val matchesCabinet = historyCabinet == "Все кабинеты" || movement.fromCabinet == historyCabinet || movement.toCabinet == historyCabinet
        val matchesWorkplace = historyWorkplace == "Все рабочие места" || movement.fromWorkplace == historyWorkplace || movement.toWorkplace == historyWorkplace
        val matchesOperation = when (historyOperation) {
            "Перемещение" -> movement.reason.contains("Перемещ", true)
            "Обслуживание" -> movement.reason.contains("Обслужив", true)
            "Изменение состояния" -> movement.reason.contains("Изменение состояния", true)
            "Архивирование" -> movement.reason.contains("Архив", true)
            "Восстановление" -> movement.reason.contains("Восстанов", true)
            else -> true
        }
        matchesText && matchesFrom && matchesTo && matchesBranch && matchesCabinet && matchesWorkplace && matchesOperation
    }.sortedByDescending { it.movedAt }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PageHero("Настройки", "Экспорт · резервные копии · справочники", Icons.Filled.Settings)
        Text("Отчёты и резервные копии", style = MaterialTheme.typography.titleMedium, color = Color(0xFF163D59))
        Button(onClick = onExportXlsx, modifier = Modifier.fillMaxWidth()) { Text("Экспорт имущества в Excel") }
        OutlinedButton(onClick = onImportExcel, modifier = Modifier.fillMaxWidth()) { Text("Импорт из Excel") }
        OutlinedButton(onClick = onExportPdf, modifier = Modifier.fillMaxWidth()) { Text("Экспорт имущества в PDF") }
        Text("История перемещений", style = MaterialTheme.typography.titleMedium, color = Color(0xFF163D59))
        OutlinedButton(onClick = { showHistoryExport = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.History, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Экспорт истории перемещений")
        }
        Text("Справочники и настройки", style = MaterialTheme.typography.titleMedium, color = Color(0xFF163D59))
        OutlinedButton(onClick = { showCharacteristicsWindow = true }, modifier = Modifier.fillMaxWidth()) { Text("Собственные характеристики имущества") }
        OutlinedButton(onClick = { showTypeWindow = true }, modifier = Modifier.fillMaxWidth()) { Text("Типы имущества и редактор иконок") }
        OutlinedButton(onClick = { showBackupWindow = true }, modifier = Modifier.fillMaxWidth()) { Text("Резервное копирование") }
        Divider()
        Text("Обслуживание данных", style = MaterialTheme.typography.titleMedium, color = Color(0xFF163D59))
        var clearStep by remember { mutableIntStateOf(0) }
        OutlinedButton(onClick = { clearStep = 1 }, modifier = Modifier.fillMaxWidth()) { Text("Очистить тестовые данные", color = MaterialTheme.colorScheme.error) }
        if (clearStep == 1) AlertDialog(onDismissRequest = { clearStep = 0 }, title = { Text("Перед очисткой создайте копию") }, text = { Text("Будут удалены филиалы, кабинеты, рабочие места, имущество (включая архив), перемещения и все инвентаризации. Справочник типов останется.") }, confirmButton = { TextButton(onClick = { onBackup(); clearStep = 2 }) { Text("Создать копию") } }, dismissButton = { TextButton(onClick = { clearStep = 2 }) { Text("Продолжить без копии") } })
        if (clearStep == 2) AlertDialog(onDismissRequest = { clearStep = 0 }, title = { Text("Подтвердите очистку") }, text = { Text("Это действие нельзя отменить. Все учётные данные на телефоне будут удалены.") }, confirmButton = { TextButton(onClick = { onClearTestData(); clearStep = 0 }) { Text("Удалить всё", color = MaterialTheme.colorScheme.error) } }, dismissButton = { TextButton(onClick = { clearStep = 0 }) { Text("Отмена") } })
    }

    if (showHistoryExport) AlertDialog(
        onDismissRequest = { showHistoryExport = false; historyMenu = 0 },
        title = { Text("Экспорт истории перемещений") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Выберите период и фильтры. В Excel попадут только подходящие записи.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF647D8D))
                OutlinedTextField(historyFilter, onHistoryFilter, label = { Text("Поиск: инв. № или название") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(dateFrom, { dateFrom = it }, label = { Text("Дата с") }, placeholder = { Text("ДД.ММ.ГГГГ") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(dateTo, { dateTo = it }, label = { Text("Дата по") }, placeholder = { Text("ДД.ММ.ГГГГ") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { historyMenu = 1 }, modifier = Modifier.fillMaxWidth()) { Text(historyBranch, modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(historyMenu == 1, { historyMenu = 0 }) {
                        DropdownMenuItem(text = { Text("Все филиалы") }, onClick = { historyBranch = "Все филиалы"; historyCabinet = "Все кабинеты"; historyWorkplace = "Все рабочие места"; historyMenu = 0 })
                        branches.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { historyBranch = b.name; historyCabinet = "Все кабинеты"; historyWorkplace = "Все рабочие места"; historyMenu = 0 }) }
                    }
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { historyMenu = 2 }, modifier = Modifier.fillMaxWidth()) { Text(historyCabinet, modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(historyMenu == 2, { historyMenu = 0 }) {
                        DropdownMenuItem(text = { Text("Все кабинеты") }, onClick = { historyCabinet = "Все кабинеты"; historyWorkplace = "Все рабочие места"; historyMenu = 0 })
                        cabinets.filter { historyBranch == "Все филиалы" || branches.firstOrNull { b -> b.id == it.branchId }?.name == historyBranch }.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { historyCabinet = c.name; historyWorkplace = "Все рабочие места"; historyMenu = 0 }) }
                    }
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { historyMenu = 3 }, modifier = Modifier.fillMaxWidth()) { Text(historyWorkplace, modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(historyMenu == 3, { historyMenu = 0 }) {
                        DropdownMenuItem(text = { Text("Все рабочие места") }, onClick = { historyWorkplace = "Все рабочие места"; historyMenu = 0 })
                        workplaces.filter { historyCabinet == "Все кабинеты" || cabinets.firstOrNull { c -> c.id == it.cabinetId }?.name == historyCabinet }.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { historyWorkplace = w.name; historyMenu = 0 }) }
                    }
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { historyMenu = 4 }, modifier = Modifier.fillMaxWidth()) { Text(historyOperation, modifier = Modifier.weight(1f)); Text("⌄") }
                    DropdownMenu(historyMenu == 4, { historyMenu = 0 }) {
                        listOf("Все операции", "Перемещение", "Обслуживание", "Изменение состояния", "Архивирование", "Восстановление").forEach { op -> DropdownMenuItem(text = { Text(op) }, onClick = { historyOperation = op; historyMenu = 0 }) }
                    }
                }
                Text("Найдено записей: ${visibleMovements.size}", style = MaterialTheme.typography.labelLarge, color = Color(0xFF176C78))
                if (dateFrom.isNotBlank() && fromMillis == null) Text("Проверьте дату начала: используйте ДД.ММ.ГГГГ", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (dateTo.isNotBlank() && toMillis == null) Text("Проверьте дату окончания: используйте ДД.ММ.ГГГГ", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (fromMillis != null && toMillis != null && fromMillis > toMillis) Text("Дата начала не может быть позже даты окончания.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(enabled = dateRangeValid, onClick = { onExportHistoryXlsx(visibleMovements); showHistoryExport = false }) { Text("Экспорт Excel") } },
        dismissButton = { TextButton(onClick = { showHistoryExport = false }) { Text("Закрыть") } }
    )
    if (showBackupWindow) AlertDialog(
        onDismissRequest = { showBackupWindow = false }, title = { Text("Резервное копирование") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Копия включает базу данных, фотографии и настройки приложения.")
            Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Text("Создать резервную копию") }
            OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { Text("Восстановить из копии") }
            Text("При восстановлении текущие данные будут заменены содержимым выбранной копии.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        } }, confirmButton = { TextButton(onClick = { showBackupWindow = false }) { Text("Закрыть") } }
    )
    if (showTypeWindow) AlertDialog(onDismissRequest = { showTypeWindow = false }, title = { Text("Типы имущества и иконки") }, text = { TypeIconEditor(assetTypes, onAddType, onUpdateType, onDeleteType) }, confirmButton = { TextButton(onClick = { showTypeWindow = false }) { Text("Готово") } })
    if (showCharacteristicsWindow) AlertDialog(onDismissRequest = { showCharacteristicsWindow = false }, title = { Text("Собственные характеристики имущества") }, text = { CustomCharacteristicsEditor(assetTypes) }, confirmButton = { TextButton(onClick = { showCharacteristicsWindow = false }) { Text("Готово") } })
}

@Composable private fun TypeIconEditor(assetTypes: List<AssetType>, onAddType:(String,String)->Unit, onUpdateType:(AssetType)->Unit, onDeleteType:(Long)->Unit) {
    var newType by remember { mutableStateOf("") }
    var newIcon by remember { mutableStateOf("devices") }
    var iconSearch by remember { mutableStateOf("") }
    val iconChoices = listOf(
        "devices" to "🧰 Универсальное оборудование", "system_unit" to "🖥️ Системный блок", "monitor" to "📺 Монитор", "printer" to "🖨️ Принтер",
        "phone" to "☎️ IP-телефон", "smartphone" to "📱 Смартфон", "battery" to "🔋 ИБП", "mfp" to "🖨️ МФУ",
        "router" to "📡 Маршрутизатор", "switch" to "🔀 Коммутатор", "server" to "🗄️ Сервер", "coordinator" to "🎛️ Координатор",
        "laptop" to "💻 Ноутбук", "network" to "🌐 Сетевое оборудование", "nas" to "💽 NAS", "rack" to "🗄️ Серверная стойка",
        "access_point" to "📶 Точка доступа Wi-Fi", "camera" to "📷 IP-камера", "patch_panel" to "🔌 Патч-панель", "scanner" to "📠 Сканер",
        "converter" to "🔗 Медиаконвертер", "barcode" to "▥ Сканер штрихкодов", "projector" to "📽️ Проектор", "tablet" to "📲 Планшет",
        "dock" to "🔌 Док-станция", "webcam" to "🎥 Веб-камера", "firewall" to "🛡️ Межсетевой экран", "cable" to "🧵 Кабельное оборудование",
        "ups" to "🔋 Источник питания", "headset" to "🎧 Гарнитура", "keyboard" to "⌨️ Клавиатура", "mouse" to "🖱️ Мышь", "storage" to "💾 Накопитель"
    )
    val available = iconChoices.filter { c -> assetTypes.none { it.iconKey == c.first } || c.first == newIcon }
    val matching = available.filter { it.first.contains(iconSearch, true) || it.second.contains(iconSearch, true) }
    Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Создание типа имущества", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(newType, { newType = it }, label = { Text("Название типа") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(iconSearch, { iconSearch = it }, label = { Text("Поиск иконки") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Text("Выберите иконку: ${typeIcon(newIcon)}", style = MaterialTheme.typography.bodyMedium)
        Column(Modifier.heightIn(max = 180.dp).verticalScroll(rememberScrollState())) {
            matching.chunked(2).forEach { pair -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { pair.forEach { c ->
                FilterChip(selected = newIcon == c.first, onClick = { newIcon = c.first }, label = { Text("${typeIcon(c.first)} ${c.second.substringAfter(' ')}", maxLines = 2) })
            } } }
        }
        Button(onClick = { if (newType.isNotBlank()) { onAddType(newType.trim(), newIcon); newType = "" } }, enabled = newType.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Добавить тип") }
        Divider()
        Text("Существующие типы", style = MaterialTheme.typography.titleSmall)
        assetTypes.forEach { type ->
            var menu by remember(type.id) { mutableStateOf(false) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${typeIcon(type.iconKey)}  ${type.name}", Modifier.weight(1f))
                TextButton(onClick = { menu = true }) { Text("Изменить иконку") }
                DropdownMenu(menu, { menu = false }) { iconChoices.forEach { c -> DropdownMenuItem(text = { Text("${c.second}") }, onClick = { onUpdateType(type.copy(iconKey=c.first)); menu = false }) } }
                IconButton(onClick = { onDeleteType(type.id) }) { Icon(Icons.Filled.Delete, "Удалить тип", tint = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

private data class CustomCharacteristic(
    val id: String,
    val name: String,
    val kind: String,
    val unit: String = "",
    val options: String = "",
    val decimal: Boolean = false,
    val multi: Boolean = false,
    val required: Boolean = false,
    val assetTypes: List<String> = emptyList()
)

private fun readCustomCharacteristics(context: android.content.Context): List<CustomCharacteristic> = runCatching {
    val raw = context.getSharedPreferences("kaen_custom_characteristics", android.content.Context.MODE_PRIVATE).getString("items", "[]") ?: "[]"
    val array = org.json.JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val item = array.optJSONObject(index) ?: return@mapNotNull null
        val name = item.optString("name").trim()
        if (name.isBlank()) return@mapNotNull null
        val typesJson = item.optJSONArray("assetTypes")
        val types = if (typesJson == null) emptyList() else (0 until typesJson.length()).map { typesJson.optString(it) }
        CustomCharacteristic(
            id = item.optString("id", "legacy_$index"), name = name,
            kind = item.optString("kind", "Текст"), unit = item.optString("unit"),
            options = item.optString("options"), decimal = item.optBoolean("decimal"),
            multi = item.optBoolean("multi"), required = item.optBoolean("required"), assetTypes = types
        )
    }
}.getOrDefault(emptyList())

private fun writeCustomCharacteristics(context: android.content.Context, entries: List<CustomCharacteristic>) {
    val array = org.json.JSONArray()
    entries.forEach { item ->
        val types = org.json.JSONArray(); item.assetTypes.forEach { types.put(it) }
        array.put(org.json.JSONObject().put("id", item.id).put("name", item.name).put("kind", item.kind)
            .put("unit", item.unit).put("options", item.options).put("decimal", item.decimal)
            .put("multi", item.multi).put("required", item.required).put("assetTypes", types))
    }
    context.getSharedPreferences("kaen_custom_characteristics", android.content.Context.MODE_PRIVATE)
        .edit().putString("items", array.toString()).apply()
}

@Composable private fun CustomCharacteristicsEditor(assetTypes: List<AssetType>) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var entries by remember { mutableStateOf(readCustomCharacteristics(context)) }
    var editingId by remember { mutableStateOf<String?>(null) }
    var name by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("Текст") }
    var unit by remember { mutableStateOf("") }
    var options by remember { mutableStateOf("") }
    var decimal by remember { mutableStateOf(false) }
    var multi by remember { mutableStateOf(false) }
    var required by remember { mutableStateOf(false) }
    var selectedTypes by remember { mutableStateOf(assetTypes.map { it.name }.toSet()) }
    var kindExpanded by remember { mutableStateOf(false) }
    fun resetEditor() {
        editingId = null; name = ""; kind = "Текст"; unit = ""; options = ""
        decimal = false; multi = false; required = false; selectedTypes = assetTypes.map { it.name }.toSet()
    }
    fun save(list: List<CustomCharacteristic>) {
        writeCustomCharacteristics(context, list); entries = list
    }
    Column(Modifier.heightIn(max = 540.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (editingId == null) "Создание характеристики" else "Редактирование характеристики", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(name, { name = it }, label = { Text("Название характеристики") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Box {
            OutlinedButton(onClick = { kindExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Тип поля: $kind") }
            DropdownMenu(kindExpanded, { kindExpanded = false }) {
                listOf("Текст", "Число", "Список", "Дата", "Да/Нет", "Многострочный текст").forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { kind = value; kindExpanded = false }) }
            }
        }
        if (kind == "Число") {
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(decimal, { decimal = it }); Text("Разрешить дробные значения") }
            OutlinedTextField(unit, { unit = it }, label = { Text("Единица измерения") }, modifier = Modifier.fillMaxWidth())
        }
        if (kind == "Список") {
            OutlinedTextField(options, { options = it }, label = { Text("Варианты через запятую") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(multi, { multi = it }); Text("Множественный выбор") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(required, { required = it }); Text("Обязательное поле") }
        Text("Привязать к типам имущества", style = MaterialTheme.typography.labelLarge)
        Text("Отметьте типы, для которых эта характеристика будет доступна.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596))
        if (assetTypes.isEmpty()) Text("Сначала создайте типы имущества.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        assetTypes.forEach { type ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = type.name in selectedTypes, onCheckedChange = { checked -> selectedTypes = if (checked) selectedTypes + type.name else selectedTypes - type.name })
                Text("${typeIcon(type.iconKey)}  ${type.name}")
            }
        }
        Button(onClick = {
            if (name.isNotBlank() && selectedTypes.isNotEmpty()) {
                val id = editingId ?: "${System.currentTimeMillis()}_${name.hashCode()}"
                val item = CustomCharacteristic(id, name.trim(), kind, unit.trim(), options.trim(), decimal, multi, required, selectedTypes.toList())
                val updated = if (editingId == null) entries + item else entries.map { if (it.id == editingId) item else it }
                save(updated); resetEditor()
            }
        }, enabled = name.isNotBlank() && selectedTypes.isNotEmpty() && (kind != "Список" || options.split(",").any { it.isNotBlank() }), modifier = Modifier.fillMaxWidth()) {
            Text(if (editingId == null) "Добавить характеристику" else "Сохранить изменения")
        }
        if (editingId != null) TextButton(onClick = { resetEditor() }, modifier = Modifier.fillMaxWidth()) { Text("Отменить редактирование") }
        Divider()
        Text("Созданные характеристики (${entries.size})", style = MaterialTheme.typography.titleSmall)
        entries.forEach { item ->
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF6FAFB))) {
                Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(item.name, fontWeight = FontWeight.SemiBold)
                    Text(buildString {
                        append(item.kind)
                        if (item.unit.isNotBlank()) append(" · ${item.unit}")
                        if (item.required) append(" · обязательное")
                        append("\nТипы: ${if (item.assetTypes.isEmpty()) "Все типы (старый параметр)" else item.assetTypes.joinToString()}")
                    }, style = MaterialTheme.typography.bodySmall, color = Color(0xFF647D8D))
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = {
                            editingId = item.id; name = item.name; kind = item.kind; unit = item.unit; options = item.options
                            decimal = item.decimal; multi = item.multi; required = item.required
                            selectedTypes = if (item.assetTypes.isEmpty()) assetTypes.map { it.name }.toSet() else item.assetTypes.toSet()
                        }) { Text("Редактировать") }
                        TextButton(onClick = { save(entries.filterNot { it.id == item.id }); if (editingId == item.id) resetEditor() }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
        Text("Параметры сохраняются на устройстве и появляются в карточке имущества только для назначенных типов.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596))
    }
}

@Composable private fun ArchiveScreen(archivedAssets: List<Asset>, movements: List<Movement>, onOpenAsset: (Asset) -> Unit, onRestoreAsset: (Asset) -> Unit) {
    var search by remember { mutableStateOf("") }
    var filtersExpanded by remember { mutableStateOf(false) }
    var typeFilter by remember { mutableStateOf("Все типы") }
    var dateFilter by remember { mutableStateOf("За всё время") }
    var branchFilter by remember { mutableStateOf("Все филиалы") }
    var menu by remember { mutableIntStateOf(0) }
    val now = System.currentTimeMillis()
    fun archivedBranch(asset: Asset): String = movements.filter { it.assetId == asset.id && it.toBranch.isNotBlank() && it.toBranch != "Архив" }.maxByOrNull { it.movedAt }?.toBranch.orEmpty()
    val branchOptions = archivedAssets.map { archivedBranch(it) }.filter { it.isNotBlank() }.distinct().sorted()
    val filtered = archivedAssets.filter { a ->
        val textMatch = search.isBlank() || a.inventoryNumber.contains(search, true) || a.name.contains(search, true) || a.type.contains(search, true)
        val typeMatch = typeFilter == "Все типы" || a.type == typeFilter
        val branchMatch = branchFilter == "Все филиалы" || archivedBranch(a) == branchFilter
        val dateMatch = when (dateFilter) { "За 7 дней" -> a.updatedAt >= now - 7L * 86_400_000L; "За 30 дней" -> a.updatedAt >= now - 30L * 86_400_000L; else -> true }
        textMatch && typeMatch && branchMatch && dateMatch
    }.sortedByDescending { it.updatedAt }
    val grouped = filtered.groupBy { SimpleDateFormat("dd MMMM yyyy", Locale("ru")).format(Date(it.updatedAt)).replaceFirstChar { c -> c.uppercase(Locale("ru")) } }
    val types = archivedAssets.map { it.type }.distinct().sorted()
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        PageHero("Архив", "${filtered.size} объектов · группировка по датам", Icons.Filled.Archive)
        FilledTonalButton(onClick = { filtersExpanded = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Filled.FilterList, null); Spacer(Modifier.width(5.dp)); Text("Фильтры архива") }
        OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Поиск по инвентарному номеру или названию") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(15.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            grouped.forEach { (day, entries) ->
                item(key = "archive_$day") { Text(day, Modifier.padding(top = 6.dp), style = MaterialTheme.typography.titleSmall, color = Color(0xFF52717A)) }
                items(entries, key = { it.id }) { a ->
                    Card(Modifier.fillMaxWidth().clickable { onOpenAsset(a) }, shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                val photo = assetPhotoPaths(a.photoPath).firstOrNull()
                                if (photo != null) AssetPhoto(photo, Modifier.size(54.dp).clip(RoundedCornerShape(12.dp))) { PhotoPlaceholder(Modifier.size(54.dp)) }
                                else Surface(Modifier.size(54.dp), shape = RoundedCornerShape(12.dp), color = Color(0xFFE7F3F6)) { Box(contentAlignment = Alignment.Center) { Text(typeIcon("devices"), style = MaterialTheme.typography.titleLarge) } }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(a.name, style = MaterialTheme.typography.titleSmall, color = Color(0xFF163D59), maxLines = 2)
                                    Text("Инв. № ${a.inventoryNumber}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF087E9A))
                                    Text("${a.type} · ${a.condition}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596))
                                }
                                Surface(shape = RoundedCornerShape(50), color = Color(0xFFF0F3F6)) { Text("Архив", Modifier.padding(horizontal = 9.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall, color = Color(0xFF637782)) }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { onOpenAsset(a) }, modifier = Modifier.weight(1f)) { Text("Открыть карточку") }
                                Button(onClick = { onRestoreAsset(a) }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Restore, null); Spacer(Modifier.width(5.dp)); Text("Восстановить") }
                            }
                        }
                    }
                }
            }
            if (filtered.isEmpty()) item { EmptyState("Архив пуст", "Измените фильтры или здесь появится архивное имущество") }
        }
    }
    if (filtersExpanded) ModalBottomSheet(onDismissRequest = { filtersExpanded = false }, containerColor = Color.White, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Фильтры архива", style = MaterialTheme.typography.titleLarge, color = Color(0xFF123B5A))
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { menu = 1 }, Modifier.fillMaxWidth()) { Text(typeFilter, Modifier.weight(1f)); Text("⌄") }
                DropdownMenu(menu == 1, { menu = 0 }) {
                    DropdownMenuItem(text = { Text("Все типы") }, onClick = { typeFilter = "Все типы"; menu = 0 })
                    types.forEach { type -> DropdownMenuItem(text = { Text(type) }, onClick = { typeFilter = type; menu = 0 }) }
                }
            }
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { menu = 2 }, Modifier.fillMaxWidth()) { Text(dateFilter, Modifier.weight(1f)); Text("⌄") }
                DropdownMenu(menu == 2, { menu = 0 }) { listOf("За всё время", "За 7 дней", "За 30 дней").forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { dateFilter = value; menu = 0 }) } }
            }
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { menu = 3 }, Modifier.fillMaxWidth()) { Text(branchFilter, Modifier.weight(1f)); Text("⌄") }
                DropdownMenu(menu == 3, { menu = 0 }) {
                    DropdownMenuItem(text = { Text("Все филиалы") }, onClick = { branchFilter = "Все филиалы"; menu = 0 })
                    branchOptions.forEach { branch -> DropdownMenuItem(text = { Text(branch) }, onClick = { branchFilter = branch; menu = 0 }) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { typeFilter = "Все типы"; dateFilter = "За всё время"; branchFilter = "Все филиалы"; filtersExpanded = false }, Modifier.weight(1f)) { Text("Сбросить") }
                Button(onClick = { filtersExpanded = false }, Modifier.weight(1f)) { Text("Применить") }
            }
        }
    }
}

@Composable private fun MoveAssetDialog(
    asset: Asset, iconKey: String, branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>,
    onDismiss: () -> Unit, onMove: (Long, Long, Long?) -> Unit
) {
    var branchId by remember(asset.id) { mutableLongStateOf(asset.branchId.takeIf { id -> branches.any { it.id == id } } ?: (branches.firstOrNull()?.id ?: 0L)) }
    val branchCabinets = cabinets.filter { it.branchId == branchId }
    var cabinetId by remember(asset.id, branchId) { mutableLongStateOf(asset.cabinetId.takeIf { id -> branchCabinets.any { it.id == id } } ?: (branchCabinets.firstOrNull()?.id ?: 0L)) }
    val cabinetWorkplaces = workplaces.filter { it.cabinetId == cabinetId }
    var workplaceId by remember(asset.id, cabinetId) { mutableStateOf(asset.workplaceId?.takeIf { id -> cabinetWorkplaces.any { it.id == id } }) }
    var menu by remember { mutableIntStateOf(0) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 18.dp).padding(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text("Перемещение имущества", style = MaterialTheme.typography.titleLarge, color = Color(0xFF123B5A))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF6F8)), shape = RoundedCornerShape(17.dp)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(13.dp), color = Color.White, modifier = Modifier.size(48.dp)) { Box(contentAlignment = Alignment.Center) { Text(typeIcon(iconKey), style = MaterialTheme.typography.titleLarge) } }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(asset.name, style = MaterialTheme.typography.titleSmall, color = Color(0xFF163D59))
                        Text("Инвентарный № ${asset.inventoryNumber}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF087E9A))
                    }
                }
            }
            Text("НОВОЕ МЕСТОПОЛОЖЕНИЕ", style = MaterialTheme.typography.labelMedium, color = Color(0xFF087E9A))
            Box {
                OutlinedButton(onClick = { menu = 1 }, modifier = Modifier.fillMaxWidth()) { Text(branches.firstOrNull { it.id == branchId }?.name ?: "Выберите филиал", modifier = Modifier.weight(1f)); Text("⌄") }
                DropdownMenu(menu == 1, { menu = 0 }) { branches.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { branchId = b.id; cabinetId = cabinets.firstOrNull { it.branchId == b.id }?.id ?: 0L; workplaceId = null; menu = 0 }) } }
            }
            Box {
                OutlinedButton(onClick = { menu = 2 }, modifier = Modifier.fillMaxWidth(), enabled = branchCabinets.isNotEmpty()) { Text(branchCabinets.firstOrNull { it.id == cabinetId }?.name ?: "Выберите кабинет", modifier = Modifier.weight(1f)); Text("⌄") }
                DropdownMenu(menu == 2, { menu = 0 }) { branchCabinets.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { cabinetId = c.id; workplaceId = null; menu = 0 }) } }
            }
            Box {
                OutlinedButton(onClick = { menu = 3 }, modifier = Modifier.fillMaxWidth(), enabled = cabinetId > 0) { Text(cabinetWorkplaces.firstOrNull { it.id == workplaceId }?.name ?: "Общее имущество кабинета", modifier = Modifier.weight(1f)); Text("⌄") }
                DropdownMenu(menu == 3, { menu = 0 }) {
                    DropdownMenuItem(text = { Text("Общее имущество кабинета") }, onClick = { workplaceId = null; menu = 0 })
                    cabinetWorkplaces.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { workplaceId = w.id; menu = 0 }) }
                }
            }
            if (branches.isEmpty() || branchCabinets.isEmpty()) Text("Для перемещения сначала создайте филиал и кабинет.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Отмена") }
                Button(onClick = { if (branchId > 0 && cabinetId > 0) onMove(branchId, cabinetId, workplaceId) }, enabled = branchId > 0 && cabinetId > 0, modifier = Modifier.weight(1f)) { Text("Подтвердить") }
            }
        }
    }
}

@Composable private fun ServiceEntrySheet(
    asset: Asset,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var description by remember(asset.id) { mutableStateOf("") }
    var comment by remember(asset.id) { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color.White, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 18.dp).padding(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Обслуживание имущества", style = MaterialTheme.typography.titleLarge, color = Color(0xFF123B5A))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF6F8)), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(asset.name, style = MaterialTheme.typography.titleSmall, color = Color(0xFF163D59))
                    Text("Инвентарный № ${asset.inventoryNumber}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF087E9A))
                }
            }
            OutlinedTextField(description, { description = it }, Modifier.fillMaxWidth(), label = { Text("Что было сделано? *") }, placeholder = { Text("Например, ремонт, диагностика, замена детали") }, minLines = 2, maxLines = 4)
            OutlinedTextField(comment, { comment = it }, Modifier.fillMaxWidth(), label = { Text("Комментарий") }, minLines = 2, maxLines = 4)
            Text("После сохранения приложение может предложить изменить состояние имущества. Изменение применяется только после подтверждения.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Отмена") }
                Button(onClick = { if (description.isNotBlank()) onSave(description, comment) }, enabled = description.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Сохранить запись") }
            }
        }
    }
}

@Composable private fun RestoreAssetDialog(asset: Asset, branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>, onDismiss: ()->Unit, onRestore:(Long,Long,Long?)->Unit) {
    var branch by remember(asset) { mutableLongStateOf(branches.firstOrNull()?.id ?: 0L) }
    var cabinet by remember(asset) { mutableLongStateOf(cabinets.firstOrNull { it.branchId==branch }?.id ?: 0L) }
    var workplace by remember(asset) { mutableLongStateOf(0L) }
    var menu by remember { mutableIntStateOf(0) }
    AlertDialog(onDismissRequest=onDismiss, title={Text("Восстановление имущества")}, text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("${asset.inventoryNumber} — ${asset.name}")
            Box { OutlinedButton(onClick={menu=1}, modifier=Modifier.fillMaxWidth()){Text(branches.firstOrNull{it.id==branch}?.name ?: "Выберите филиал")}; DropdownMenu(menu==1,{menu=0}) { branches.forEach { b -> DropdownMenuItem(text={Text(b.name)},onClick={branch=b.id;cabinet=cabinets.firstOrNull{it.branchId==b.id}?.id ?: 0L;workplace=0L;menu=0}) } } }
            Box { OutlinedButton(onClick={menu=2}, modifier=Modifier.fillMaxWidth()){Text(cabinets.firstOrNull{it.id==cabinet}?.name ?: "Выберите кабинет")}; DropdownMenu(menu==2,{menu=0}) { cabinets.filter{it.branchId==branch}.forEach { c -> DropdownMenuItem(text={Text(c.name)},onClick={cabinet=c.id;workplace=0L;menu=0}) } } }
            Box { OutlinedButton(onClick={menu=3}, modifier=Modifier.fillMaxWidth()){Text(workplaces.firstOrNull{it.id==workplace}?.name ?: "Общее имущество кабинета")}; DropdownMenu(menu==3,{menu=0}) { DropdownMenuItem(text={Text("Общее имущество кабинета")},onClick={workplace=0L;menu=0}); workplaces.filter{it.cabinetId==cabinet}.forEach { w -> DropdownMenuItem(text={Text(w.name)},onClick={workplace=w.id;menu=0}) } } }
        }
    }, confirmButton={TextButton(enabled=branch>0 && cabinet>0,onClick={onRestore(branch,cabinet,workplace.takeIf{it>0})}){Text("Восстановить")}}, dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

@Composable private fun StructureDialog(branches: List<Branch>, cabinets: List<Cabinet>, onDismiss: () -> Unit, onSave: (String, Long, String) -> Unit) {
    var kind by remember { mutableStateOf("branch") }
    var selectedBranchId by remember { mutableLongStateOf(branches.firstOrNull()?.id ?: 0L) }
    var selectedCabinetId by remember { mutableLongStateOf(cabinets.firstOrNull { it.branchId == selectedBranchId }?.id ?: 0L) }
    var name by remember { mutableStateOf("") }
    var branchMenu by remember { mutableStateOf(false) }
    var cabinetMenu by remember { mutableStateOf(false) }
    val branchCabinets = cabinets.filter { it.branchId == selectedBranchId }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Добавить элемент структуры") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("branch" to "Филиал", "cabinet" to "Кабинет", "workplace" to "Рабочее место").forEach { (value, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = kind == value, onClick = {
                        kind = value
                        selectedCabinetId = cabinets.firstOrNull { it.branchId == selectedBranchId }?.id ?: 0L
                    })
                    Text(label)
                }
            }
            if (kind != "branch") {
                Box {
                    OutlinedButton(onClick = { branchMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(branches.firstOrNull { it.id == selectedBranchId }?.name ?: "Выберите филиал")
                    }
                    DropdownMenu(branchMenu, { branchMenu = false }) {
                        branches.forEach { branch ->
                            DropdownMenuItem(text = { Text(branch.name) }, onClick = {
                                selectedBranchId = branch.id
                                selectedCabinetId = cabinets.firstOrNull { it.branchId == branch.id }?.id ?: 0L
                                branchMenu = false
                            })
                        }
                    }
                }
            }
            if (kind == "workplace") {
                Box {
                    OutlinedButton(onClick = { cabinetMenu = true }, modifier = Modifier.fillMaxWidth(), enabled = branchCabinets.isNotEmpty()) {
                        Text(branchCabinets.firstOrNull { it.id == selectedCabinetId }?.name ?: "Выберите кабинет")
                    }
                    DropdownMenu(cabinetMenu, { cabinetMenu = false }) {
                        branchCabinets.forEach { cabinet ->
                            DropdownMenuItem(text = { Text(cabinet.name) }, onClick = { selectedCabinetId = cabinet.id; cabinetMenu = false })
                        }
                    }
                }
                if (branchCabinets.isEmpty()) Text("В выбранном филиале пока нет кабинетов", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
    }, confirmButton = {
        TextButton(onClick = {
            val parentId = when (kind) { "cabinet" -> selectedBranchId; "workplace" -> selectedCabinetId; else -> 0L }
            if (name.isNotBlank() && (kind == "branch" || parentId > 0L)) onSave(kind, parentId, name.trim())
        }, enabled = name.isNotBlank() && (kind == "branch" || if (kind == "cabinet") selectedBranchId > 0L else selectedCabinetId > 0L)) { Text("Добавить") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@Composable private fun AssetDialog(
    asset: Asset?, branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>, assetTypesFromDb: List<AssetType>,
    onDismiss: () -> Unit, onSave: (Asset, String, String) -> Unit
) {
    val context = LocalContext.current
    var inventoryNumber by remember(asset) { mutableStateOf(asset?.inventoryNumber ?: "") }
    var serialNumber by remember(asset) { mutableStateOf(asset?.serialNumber ?: "") }
    var name by remember(asset) { mutableStateOf(asset?.name ?: "") }
    var brand by remember(asset) { mutableStateOf(asset?.brand ?: "") }
    var model by remember(asset) { mutableStateOf(asset?.model ?: "") }
    var notes by remember(asset) { mutableStateOf(asset?.notes ?: "") }
    val fallbackTypes = listOf("Системный блок", "Монитор", "Принтер", "IP-телефон", "Смартфон", "ИБП", "МФУ", "Маршрутизатор", "Коммутатор", "Сервер", "Координатор", "Ноутбук", "Прочее")
    val fallbackIcons = listOf("system_unit", "monitor", "printer", "phone", "smartphone", "battery", "mfp", "router", "switch", "server", "coordinator", "laptop", "devices")
    val assetTypes = assetTypesFromDb.ifEmpty { fallbackTypes.mapIndexed { index, title -> AssetType(id = -(index + 1L), name = title, iconKey = fallbackIcons[index]) } }
    var assetType by remember(asset, assetTypes) { mutableStateOf(assetTypes.firstOrNull { it.name == asset?.type } ?: assetTypes.first()) }
    var typeMenu by remember { mutableStateOf(false) }
    var branchId by remember(asset) { mutableLongStateOf(asset?.branchId ?: branches.firstOrNull()?.id ?: 0L) }
    var cabinetId by remember(asset) { mutableLongStateOf(asset?.cabinetId ?: cabinets.firstOrNull { it.branchId == branchId }?.id ?: 0L) }
    var workplaceId by remember(asset) { mutableLongStateOf(asset?.workplaceId ?: 0L) }
    var condition by remember(asset) { mutableStateOf(asset?.condition ?: "Исправно") }
    var acquiredDate by remember(asset) { mutableStateOf(asset?.acquiredDate ?: "") }
    var costText by remember(asset) { mutableStateOf(if ((asset?.cost ?: 0.0) == 0.0) "" else asset!!.cost.toString()) }
    val costValue = costText.replace(" ", "").replace(",", ".").toDoubleOrNull() ?: 0.0
    val customPrefs = remember { context.getSharedPreferences("kaen_asset_characteristics", android.content.Context.MODE_PRIVATE) }
    val customDefinitions = readCustomCharacteristics(context).filter { it.assetTypes.isEmpty() || assetType.name in it.assetTypes }
    var customValues by remember(asset) { mutableStateOf(runCatching {
        val key = asset?.id?.takeIf { it > 0 }?.toString() ?: asset?.inventoryNumber.orEmpty()
        val stored = customPrefs.getString("asset_$key", null) ?: customPrefs.getString("asset_${asset?.inventoryNumber.orEmpty()}", "{}")
        val json = org.json.JSONObject(stored ?: "{}")
        json.keys().asSequence().associateWith { json.optString(it) }
    }.getOrDefault(emptyMap())) }
    val requiredCustomMissing = customDefinitions.any { it.required && customValues[it.id].isNullOrBlank() }
    var moveReason by remember(asset) { mutableStateOf("") }
    var moveComment by remember(asset) { mutableStateOf("") }
    var menu by remember { mutableIntStateOf(0) }
    var photoPaths by remember(asset) { mutableStateOf(asset?.photoPath?.let(::assetPhotoPaths) ?: emptyList()) }
    var cameraFile by remember { mutableStateOf<File?>(null) }
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            val directory = File(context.filesDir, "photos").apply { mkdirs() }
            val copied = uris.mapNotNull { uri -> runCatching {
                val target = File(directory, "asset_${System.currentTimeMillis()}_${photoPaths.size}.jpg")
                context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use(input::copyTo) }
                target.absolutePath
            }.getOrNull() }
            photoPaths = photoPaths + copied
        }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) cameraFile?.absolutePath?.let { photoPaths = photoPaths + it }
    }
    val selectedBranch = branches.firstOrNull { it.id == branchId }?.name ?: "Выбрать филиал"
    val selectedCabinet = cabinets.firstOrNull { it.id == cabinetId }?.name ?: "Выбрать кабинет"
    val selectedWorkplace = workplaces.firstOrNull { it.id == workplaceId }?.name ?: "Общее имущество кабинета"

    @Composable fun Section(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
        Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = Color(0xFFF5FAFC), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDCEAF0))) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = Color(0xFF075B78))
                if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color(0xFF66808D))
                content()
            }
        }
    }
    @Composable fun Field(value: String, onValue: (String) -> Unit, label: String, placeholder: String? = null) {
        OutlinedTextField(
            value = value, onValueChange = onValue, label = { Text(label) },
            placeholder = placeholder?.let { { Text(it) } }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF0786A3), focusedLabelColor = Color(0xFF0786A3), unfocusedBorderColor = Color(0xFFD1E0E7), unfocusedContainerColor = Color.White, focusedContainerColor = Color.White)
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.92f).imePadding().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(if (asset == null) "Новое имущество" else "Редактирование имущества", color = Color(0xFF073B70), style = MaterialTheme.typography.titleLarge)
                    Text("Все сведения на одном экране", color = Color(0xFF6A8290), style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Закрыть") }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Section("ОСНОВНАЯ ИНФОРМАЦИЯ", "Обязательные поля отмечены звёздочкой") {
                    Field(inventoryNumber, { inventoryNumber = it }, "Инвентарный номер *", "Например, INV-001")
                    Field(name, { name = it }, "Название имущества *", "Например, Рабочий компьютер")
                    Field(serialNumber, { serialNumber = it }, "Серийный номер")
                    Field(brand, { brand = it }, "Производитель")
                    Field(model, { model = it }, "Модель")
                }
                Section("ТИП ИМУЩЕСТВА") {
                    Box {
                        Surface(Modifier.fillMaxWidth().clickable { typeMenu = true }, shape = RoundedCornerShape(15.dp), color = Color.White, border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF9ACBD7))) {
                            Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFE1F5F7)) { Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) { Text(typeIcon(assetType.iconKey), style = MaterialTheme.typography.headlineMedium) } }
                                Column(Modifier.weight(1f)) { Text("Выбранный тип", style = MaterialTheme.typography.labelSmall, color = Color(0xFF6A8290)); Text(assetType.name, style = MaterialTheme.typography.titleMedium, color = Color(0xFF123F5B)) }
                                Text("⌄", style = MaterialTheme.typography.titleLarge, color = Color(0xFF0786A3))
                            }
                        }
                        DropdownMenu(typeMenu, { typeMenu = false }, modifier = Modifier.heightIn(max = 340.dp)) {
                            assetTypes.forEach { type -> DropdownMenuItem(text = { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) { Text(typeIcon(type.iconKey), style = MaterialTheme.typography.titleLarge); Text(type.name) } }, onClick = { assetType = type; typeMenu = false }) }
                        }
                    }
                }
                Section("ПРИОБРЕТЕНИЕ И СОСТОЯНИЕ") {
                    Field(condition, { condition = it }, "Состояние", "Исправно")
                    Field(acquiredDate, { acquiredDate = it }, "Дата приобретения", "ДД.ММ.ГГГГ")
                    Field(costText, { costText = it }, "Первоначальная стоимость, ₽", "Например, 45000")
                }
                if (customDefinitions.isNotEmpty()) Section("ДОПОЛНИТЕЛЬНЫЕ ХАРАКТЕРИСТИКИ", "Параметры для типа «${assetType.name}»") {
                    customDefinitions.forEach { characteristic ->
                        val currentValue = customValues[characteristic.id].orEmpty()
                        when (characteristic.kind) {
                            "Многострочный текст" -> OutlinedTextField(currentValue, { customValues = customValues + (characteristic.id to it) }, label = { Text(characteristic.name + if (characteristic.required) " *" else "") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                            "Да/Нет" -> {
                                Text(characteristic.name + if (characteristic.required) " *" else "", style = MaterialTheme.typography.labelLarge)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(selected = currentValue == "Да", onClick = { customValues = customValues + (characteristic.id to "Да") }, label = { Text("Да") })
                                    FilterChip(selected = currentValue == "Нет", onClick = { customValues = customValues + (characteristic.id to "Нет") }, label = { Text("Нет") })
                                }
                            }
                            "Список" -> {
                                val choices = characteristic.options.split(",").map { it.trim() }.filter { it.isNotBlank() }
                                Text(characteristic.name + if (characteristic.required) " *" else "", style = MaterialTheme.typography.labelLarge)
                                if (characteristic.multi) {
                                    val selectedValues = currentValue.split("|").filter { it.isNotBlank() }.toSet()
                                    Column {
                                        choices.forEach { option ->
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Checkbox(checked = option in selectedValues, onCheckedChange = { checked ->
                                                    val next = if (checked) selectedValues + option else selectedValues - option
                                                    customValues = customValues + (characteristic.id to next.joinToString("|"))
                                                })
                                                Text(option)
                                            }
                                        }
                                    }
                                } else {
                                    var optionMenu by remember(characteristic.id) { mutableStateOf(false) }
                                    Box {
                                        OutlinedButton(onClick = { optionMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(currentValue.ifBlank { "Выбрать значение" }, modifier = Modifier.weight(1f)); Text("⌄") }
                                        DropdownMenu(optionMenu, { optionMenu = false }) {
                                            choices.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { customValues = customValues + (characteristic.id to option); optionMenu = false }) }
                                        }
                                    }
                                }
                            }
                            else -> OutlinedTextField(currentValue, { customValues = customValues + (characteristic.id to it) }, label = { Text(characteristic.name + (if (characteristic.required) " *" else "") + (if (characteristic.unit.isNotBlank()) " (${characteristic.unit})" else "")) }, modifier = Modifier.fillMaxWidth(), singleLine = characteristic.kind != "Многострочный текст")
                        }
                    }
                }
                Section("ФОТОГРАФИИ", "Можно добавить несколько фотографий") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { galleryPicker.launch("image/*") }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.PhotoLibrary, null); Spacer(Modifier.width(6.dp)); Text("Галерея") }
                        OutlinedButton(onClick = {
                            runCatching {
                                val directory = File(context.filesDir, "photos").apply { mkdirs() }
                                val file = File(directory, "camera_${System.currentTimeMillis()}.jpg")
                                val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                                cameraFile = file
                                cameraLauncher.launch(uri)
                            }
                        }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.CameraAlt, null); Spacer(Modifier.width(6.dp)); Text("Камера") }
                    }
                    if (photoPaths.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(photoPaths) { path ->
                                Box {
                                    AssetPhoto(path, Modifier.size(104.dp).clip(RoundedCornerShape(14.dp))) { PhotoPlaceholder(Modifier.size(104.dp)) }
                                    Surface(Modifier.align(Alignment.TopEnd).padding(4.dp).size(25.dp).clickable { photoPaths = photoPaths.filterNot { it == path } }, shape = RoundedCornerShape(50), color = Color.White.copy(alpha = 0.92f)) {
                                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Close, contentDescription = "Удалить фото", tint = Color(0xFFB34C4C), modifier = Modifier.size(16.dp)) }
                                    }
                                }
                            }
                        }
                    } else Text("Фотографии пока не добавлены", style = MaterialTheme.typography.bodySmall, color = Color(0xFF718596))
                }
                Section("МЕСТОПОЛОЖЕНИЕ", "Филиал → кабинет → рабочее место") {
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { menu = 1 }, modifier = Modifier.fillMaxWidth()) { Text("🏢   $selectedBranch", modifier = Modifier.weight(1f)); Text("⌄") }
                        DropdownMenu(menu == 1, { menu = 0 }) { branches.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { branchId = b.id; cabinetId = cabinets.firstOrNull { it.branchId == b.id }?.id ?: 0L; workplaceId = 0L; menu = 0 }) } }
                    }
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { menu = 2 }, modifier = Modifier.fillMaxWidth(), enabled = branchId > 0) { Text("🚪   $selectedCabinet", modifier = Modifier.weight(1f)); Text("⌄") }
                        DropdownMenu(menu == 2, { menu = 0 }) { cabinets.filter { it.branchId == branchId }.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { cabinetId = c.id; workplaceId = 0L; menu = 0 }) } }
                    }
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { menu = 3 }, modifier = Modifier.fillMaxWidth(), enabled = cabinetId > 0) { Text("🪑   $selectedWorkplace", modifier = Modifier.weight(1f)); Text("⌄") }
                        DropdownMenu(menu == 3, { menu = 0 }) {
                            DropdownMenuItem(text = { Text("Общее имущество кабинета") }, onClick = { workplaceId = 0L; menu = 0 })
                            workplaces.filter { it.cabinetId == cabinetId }.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { workplaceId = w.id; menu = 0 }) }
                        }
                    }
                }
                Section("ДОПОЛНИТЕЛЬНАЯ ИНФОРМАЦИЯ") { Field(notes, { notes = it }, "Примечание") }
                if (asset != null) Section("ПРИЧИНА ИЗМЕНЕНИЯ МЕСТА", "Заполняйте, если одновременно перемещаете имущество") {
                    Field(moveReason, { moveReason = it }, "Причина перемещения")
                    Field(moveComment, { moveComment = it }, "Комментарий")
                }
                if (inventoryNumber.isBlank() || name.isBlank()) Text("* Заполните инвентарный номер и название, чтобы сохранить имущество", color = Color(0xFFB45A35), style = MaterialTheme.typography.bodySmall)
                if (requiredCustomMissing) Text("Заполните обязательные дополнительные характеристики.", color = Color(0xFFB45A35), style = MaterialTheme.typography.bodySmall)
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Отмена") }
                Button(
                    onClick = {
                        if (inventoryNumber.isNotBlank() && name.isNotBlank() && branchId > 0 && cabinetId > 0) {
                            val customJson = org.json.JSONObject(); customValues.forEach { (key, value) -> customJson.put(key, value) }
                            val customKey = asset?.id?.takeIf { it > 0 }?.toString() ?: inventoryNumber.trim()
                            customPrefs.edit().putString("asset_$customKey", customJson.toString()).apply()
                            onSave(Asset(
                                id = asset?.id ?: 0L, inventoryNumber = inventoryNumber.trim(), serialNumber = serialNumber.trim(),
                                name = name.trim(), brand = brand.trim(), model = model.trim(), type = assetType.name,
                                branchId = branchId, cabinetId = cabinetId, workplaceId = workplaceId.takeIf { it > 0 },
                                condition = condition, notes = notes, photoPath = photoPaths.joinToString("\n"), active = asset?.active ?: true,
                                acquiredDate = acquiredDate, cost = costValue
                            ), moveReason, moveComment)
                        }
                    },
                    enabled = inventoryNumber.isNotBlank() && name.isNotBlank() && branchId > 0 && cabinetId > 0 && !requiredCustomMissing,
                    modifier = Modifier.weight(1f)
                ) { Text("Сохранить") }
            }
        }
    }
}

