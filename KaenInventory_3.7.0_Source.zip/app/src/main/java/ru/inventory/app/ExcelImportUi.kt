package ru.inventory.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class ExcelImportReady(val row: ExcelAssetRow, val branchId: Long, val cabinetId: Long, val workplaceId: Long?)

@Composable
fun ExcelImportReviewDialog(
    rows: List<ExcelAssetRow>, branches: List<Branch>, cabinets: List<Cabinet>, workplaces: List<Workplace>, existingNumbers: Set<String>, assetTypes: List<AssetType>,
    characteristicTypes: Map<String, Set<String>>, onDismiss: () -> Unit,
    onDraftChange: (List<ExcelAssetRow>) -> Unit,
    onImport: (List<ExcelImportReady>, Set<String>, Set<String>, Int) -> Unit
) {
    var drafts by remember { mutableStateOf(rows.map { row ->
        val branch = branches.firstOrNull { it.id == row.mappedBranchId } ?: branches.firstOrNull { it.name.equals(row.branchName, true) }
        val cabinetName = row.cabinetLabel.substringBefore("/").trim()
        val cabinet = cabinets.firstOrNull { it.id == row.mappedCabinetId && it.branchId == branch?.id }
            ?: cabinets.firstOrNull { it.branchId == branch?.id && it.name.equals(cabinetName, true) }
        val workplaceName = row.cabinetLabel.substringAfter("/", "").trim()
        val workplace = workplaces.firstOrNull { it.id == row.mappedWorkplaceId && it.cabinetId == cabinet?.id }
            ?: workplaces.firstOrNull { it.cabinetId == cabinet?.id && it.name.equals(workplaceName, true) }
        row to Triple(branch?.id ?: 0L, cabinet?.id ?: 0L, workplace?.id)
    }) }
    LaunchedEffect(drafts) { onDraftChange(drafts.map { (row, location) -> row.copy(mappedBranchId = location.first.takeIf { it > 0L }, mappedCabinetId = location.second.takeIf { it > 0L }, mappedWorkplaceId = location.third) }) }
    var createUnknownTypes by remember { mutableStateOf(false) }
    var createUnknownCharacteristics by remember { mutableStateOf(false) }
    var expandedIndex by remember { mutableIntStateOf(-1) }
    var skippedIndices by remember { mutableStateOf(rows.mapIndexedNotNull { index, row -> if (row.skipped) index else null }.toSet()) }
    val activeForDuplicates = drafts.filterIndexed { index, _ -> index !in skippedIndices }
    val duplicateNumbers = activeForDuplicates.groupingBy { it.first.inventoryNumber.trim().lowercase() }.eachCount().filter { it.key.isNotBlank() && it.value > 1 }.keys
    fun isDuplicate(row: ExcelAssetRow) = existingNumbers.contains(row.inventoryNumber.trim().lowercase()) || duplicateNumbers.contains(row.inventoryNumber.trim().lowercase())
    val importable = drafts.mapNotNull { (row, branchAndCabinet) ->
        val (branchId, cabinetId, workplaceId) = branchAndCabinet
        if (row.inventoryNumber.isBlank() || row.displayName.isBlank() || row.type.isBlank() || branchId == 0L || cabinetId == 0L || isDuplicate(row) || drafts.indexOfFirst { it.first.sourceRow == row.sourceRow && it.first.sheetName == row.sheetName } in skippedIndices) null
        else ExcelImportReady(row, branchId, cabinetId, workplaceId)
    }
    val duplicates = activeForDuplicates.count { (row, _) -> isDuplicate(row) }
    val activeDrafts = drafts.filterIndexed { index, _ -> index !in skippedIndices }
    val unknownTypes = activeDrafts.map { it.first.type }.filter { type -> type.isNotBlank() && assetTypes.none { it.name.equals(type, true) } }.toSet()
    val unknownCharacteristics = activeDrafts.flatMap { (row, _) -> row.customValues.keys.filter { field ->
        val attachedTypes = characteristicTypes[field]
        attachedTypes == null || (attachedTypes.isNotEmpty() && row.type !in attachedTypes)
    } }.toSet()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Проверка импорта Excel") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Найдено строк: ${rows.size}. Можно исправить данные до добавления. Повторяющиеся инвентарные номера не будут импортированы.", style = MaterialTheme.typography.bodySmall)
                Text("Готово: ${importable.size} · Дубликаты: $duplicates · Пропущено вручную: ${skippedIndices.size} · Требуют настройки: ${(rows.size - importable.size - duplicates - skippedIndices.size).coerceAtLeast(0)}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                if (unknownTypes.isNotEmpty()) {
                    Text("Новые типы: ${unknownTypes.joinToString()}", style = MaterialTheme.typography.bodySmall)
                    Row { Checkbox(createUnknownTypes, { createUnknownTypes = it }); Text("Создать эти типы после подтверждения") }
                }
                if (unknownCharacteristics.isNotEmpty()) {
                    Text("Для некоторых типов имущества отсутствуют характеристики: ${unknownCharacteristics.joinToString()}", style = MaterialTheme.typography.bodySmall)
                    Row { Checkbox(createUnknownCharacteristics, { createUnknownCharacteristics = it }); Text("Создать недостающие характеристики и привязать к типам") }
                }
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    itemsIndexed(drafts, key = { index, pair -> "${pair.first.sheetName}_${pair.first.sourceRow}_$index" }) { index, pair ->
                        val row = pair.first; val (branchId, cabinetId, workplaceId) = pair.second
                        val duplicate = isDuplicate(row)
                        Card(colors = CardDefaults.cardColors(containerColor = if (duplicate) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${row.inventoryNumber.ifBlank { "Без номера" }} · ${row.displayName}", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                                    TextButton(onClick = { expandedIndex = if (expandedIndex == index) -1 else index }) { Text(if (expandedIndex == index) "Свернуть" else "Изменить") }
                                }
                                Text("${row.type} · ${row.branchName} · ${row.cabinetLabel}", style = MaterialTheme.typography.bodySmall)
                                when {
                                    duplicate -> Text("Дубликат: такой номер уже есть в базе или файле. Строка будет пропущена.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                                    row.inventoryNumber.isBlank() || row.displayName.isBlank() || row.type.isBlank() -> Text("Заполните инвентарный номер, название и тип имущества.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                                    branchId == 0L || cabinetId == 0L -> Text("Нужно сопоставить филиал и кабинет.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                                    else -> Text("Готово к импорту", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                                }
                                if (expandedIndex == index) {
                                    var inventory by remember(index, row.inventoryNumber) { mutableStateOf(row.inventoryNumber) }
                                    var name by remember(index, row.displayName) { mutableStateOf(row.displayName) }
                                    var type by remember(index, row.type) { mutableStateOf(row.type) }
                                    var serial by remember(index, row.serialNumber) { mutableStateOf(row.serialNumber) }
                                    var notes by remember(index, row.notes) { mutableStateOf(row.notes) }
                                    OutlinedTextField(inventory, { inventory = it; drafts = drafts.toMutableList().also { list -> list[index] = list[index].first.copy(inventoryNumber = it) to list[index].second } }, label = { Text("Инвентарный номер") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(name, { name = it; drafts = drafts.toMutableList().also { list -> list[index] = list[index].first.copy(displayName = it) to list[index].second } }, label = { Text("Название") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(type, { type = it; drafts = drafts.toMutableList().also { list -> list[index] = list[index].first.copy(type = it) to list[index].second } }, label = { Text("Тип имущества") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(serial, { serial = it; drafts = drafts.toMutableList().also { list -> list[index] = list[index].first.copy(serialNumber = it) to list[index].second } }, label = { Text("Серийный номер") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(notes, { notes = it; drafts = drafts.toMutableList().also { list -> list[index] = list[index].first.copy(notes = it) to list[index].second } }, label = { Text("Примечание") }, modifier = Modifier.fillMaxWidth())
                                    row.customValues.forEach { (fieldName, fieldValue) ->
                                        OutlinedTextField(fieldValue, { value -> drafts = drafts.toMutableList().also { list ->
                                            val current = list[index].first
                                            list[index] = current.copy(customValues = current.customValues + (fieldName to value)) to list[index].second
                                        } }, label = { Text(fieldName) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    }
                                    Text("Филиал", style = MaterialTheme.typography.labelMedium)
                                    var branchMenu by remember(index) { mutableStateOf(false) }
                                    Box { OutlinedButton(onClick = { branchMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(branches.firstOrNull { it.id == branchId }?.name ?: "Выберите филиал") }; DropdownMenu(branchMenu, { branchMenu = false }) { branches.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { drafts = drafts.toMutableList().also { list -> list[index] = list[index].first.copy(mappedBranchId = b.id, mappedCabinetId = null, mappedWorkplaceId = null) to Triple(b.id, 0L, null) }; branchMenu = false }) } } }
                                    Text("Кабинет", style = MaterialTheme.typography.labelMedium)
                                    var cabinetMenu by remember(index) { mutableStateOf(false) }
                                    Box { OutlinedButton(onClick = { cabinetMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(cabinets.firstOrNull { it.id == cabinetId }?.name ?: "Выберите кабинет") }; DropdownMenu(cabinetMenu, { cabinetMenu = false }) { cabinets.filter { it.branchId == branchId }.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { drafts = drafts.toMutableList().also { list -> list[index] = list[index].first.copy(mappedBranchId = branchId, mappedCabinetId = c.id, mappedWorkplaceId = null) to Triple(branchId, c.id, null) }; cabinetMenu = false }) } } }
                                    var workplaceMenu by remember(index) { mutableStateOf(false) }
                                    Box { OutlinedButton(onClick = { workplaceMenu = true }, modifier = Modifier.fillMaxWidth(), enabled = cabinetId > 0L) { Text(workplaces.firstOrNull { it.id == workplaceId }?.name ?: "Общее имущество кабинета") }; DropdownMenu(workplaceMenu, { workplaceMenu = false }) {
                                        DropdownMenuItem(text = { Text("Общее имущество кабинета") }, onClick = { drafts = drafts.toMutableList().also { list -> list[index] = list[index].first.copy(mappedBranchId = branchId, mappedCabinetId = cabinetId, mappedWorkplaceId = null) to Triple(branchId, cabinetId, null) }; workplaceMenu = false })
                                        workplaces.filter { it.cabinetId == cabinetId }.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { drafts = drafts.toMutableList().also { list -> list[index] = list[index].first.copy(mappedBranchId = branchId, mappedCabinetId = cabinetId, mappedWorkplaceId = w.id) to Triple(branchId, cabinetId, w.id) }; workplaceMenu = false }) }
                                    } }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { Button(enabled = importable.isNotEmpty() && (unknownTypes.isEmpty() || createUnknownTypes) && (unknownCharacteristics.isEmpty() || createUnknownCharacteristics), onClick = { onImport(importable, if (createUnknownTypes) unknownTypes else emptySet(), if (createUnknownCharacteristics) unknownCharacteristics else emptySet(), rows.size - importable.size) }) { Text("Добавить ${importable.size}") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
