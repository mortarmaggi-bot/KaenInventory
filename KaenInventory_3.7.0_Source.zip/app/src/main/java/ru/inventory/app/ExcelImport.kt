package ru.inventory.app

import android.content.Context
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.util.zip.ZipInputStream

/** Reads the XLSX register produced by Exporter.assetsXlsx(). Supports inline and shared strings. */
data class ExcelAssetRow(
    val sheetName: String,
    val branchName: String,
    val cabinetLabel: String,
    val type: String,
    val inventoryNumber: String,
    val displayName: String,
    val serialNumber: String,
    val notes: String,
    val sourceRow: Int,
    val brand: String = "",
    val model: String = "",
    val customValues: Map<String, String> = emptyMap(),
    val mappedBranchId: Long? = null,
    val mappedCabinetId: Long? = null,
    val mappedWorkplaceId: Long? = null,
    val skipped: Boolean = false
)

object ExcelInventoryImporter {
    fun read(context: Context, uri: Uri): List<ExcelAssetRow> {
        val entries = linkedMapOf<String, ByteArray>()
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (!entry.isDirectory) entries[entry.name] = zip.readBytes()
                    zip.closeEntry()
                }
            }
        } ?: error("Не удалось открыть выбранный файл")
        val workbook = entries["xl/workbook.xml"] ?: error("Файл не похож на книгу Excel: отсутствует workbook.xml")
        val rels = entries["xl/_rels/workbook.xml.rels"] ?: error("В файле отсутствуют связи листов Excel")
        val relationships = parseRelationships(rels)
        val shared = entries["xl/sharedStrings.xml"]?.let(::parseSharedStrings).orEmpty()
        val result = mutableListOf<ExcelAssetRow>()
        parseSheets(workbook).forEach { (sheetName, relId) ->
            val target = relationships[relId] ?: return@forEach
            val path = normalizeSheetPath(target)
            val bytes = entries[path] ?: return@forEach
            val rows = parseSheet(bytes, shared)
            val branchLine = rows.firstOrNull { it.first == 2 }?.second?.get(0).orEmpty()
            val branch = branchLine.substringAfter(':', "").trim()
            val headers = rows.firstOrNull { it.first == 4 }?.second.orEmpty()
            val customHeaders = headers.filterKeys { it >= 9 }.mapValues { it.value.trim() }.filterValues { it.isNotBlank() }
            var lastCabinet = ""
            rows.filter { it.first >= 5 }.forEach { (rowNo, cells) ->
                if (!cells[0].isNullOrBlank()) lastCabinet = cells[0].orEmpty().trim()
                val inventory = cells[2].orEmpty().trim()
                val nameParts = cells[3].orEmpty().split(" · ")
                val name = nameParts.firstOrNull().orEmpty().trim()
                val type = cells[1].orEmpty().trim()
                val hasAssetData = cells.any { (column, value) -> column > 0 && value.isNotBlank() } &&
                    !cells.values.any { it.trim().equals("Нет данных", true) }
                if (hasAssetData) {
                    result += ExcelAssetRow(
                        sheetName = sheetName, branchName = branch,
                        cabinetLabel = lastCabinet, type = type,
                        inventoryNumber = inventory, displayName = name,
                        serialNumber = cells[4].orEmpty().trim(), notes = cells[7].orEmpty().trim(),
                        sourceRow = rowNo, brand = nameParts.getOrNull(1).orEmpty().trim(),
                        model = nameParts.getOrNull(2).orEmpty().trim(),
                        customValues = customHeaders.mapNotNull { (column, header) -> cells[column]?.takeIf { it.isNotBlank() }?.let { header to it } }.toMap()
                    )
                }
            }
        }
        if (result.isEmpty()) error("В книге не найдены строки имущества. Выберите файл, экспортированный из KaenInventory.")
        return result
    }

    private fun normalizeSheetPath(target: String): String {
        val clean = target.replace('\\', '/').removePrefix("/")
        return if (clean.startsWith("xl/")) clean else "xl/$clean"
    }

    private fun parser(bytes: ByteArray) = Xml.newPullParser().apply {
        setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        setInput(bytes.inputStream(), "UTF-8")
    }

    private fun parseRelationships(bytes: ByteArray): Map<String, String> {
        val p = parser(bytes); val map = mutableMapOf<String, String>()
        while (p.next() != XmlPullParser.END_DOCUMENT) if (p.eventType == XmlPullParser.START_TAG && p.name == "Relationship") {
            val id = p.getAttributeValue(null, "Id")
            val target = p.getAttributeValue(null, "Target")
            if (id != null && target != null) map[id] = target
        }
        return map
    }

    private fun parseSheets(bytes: ByteArray): List<Pair<String, String>> {
        val p = parser(bytes); val list = mutableListOf<Pair<String, String>>()
        while (p.next() != XmlPullParser.END_DOCUMENT) if (p.eventType == XmlPullParser.START_TAG && p.name == "sheet") {
            val name = p.getAttributeValue(null, "name") ?: "Лист"
            val rel = p.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id")
                ?: p.getAttributeValue(null, "r:id")
            if (rel != null) list += name to rel
        }
        return list
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val p = parser(bytes); val values = mutableListOf<String>(); var inSi = false; var inText = false
        val current = StringBuilder()
        while (p.next() != XmlPullParser.END_DOCUMENT) when (p.eventType) {
            XmlPullParser.START_TAG -> when (p.name) { "si" -> { inSi = true; current.setLength(0) }; "t" -> if (inSi) inText = true }
            XmlPullParser.TEXT -> if (inText) current.append(p.text)
            XmlPullParser.END_TAG -> when (p.name) { "t" -> inText = false; "si" -> { values += current.toString(); inSi = false } }
        }
        return values
    }

    private fun parseSheet(bytes: ByteArray, shared: List<String>): List<Pair<Int, Map<Int, String>>> {
        val p = parser(bytes); val rows = mutableListOf<Pair<Int, Map<Int, String>>>()
        var rowNo = 0; var cells = linkedMapOf<Int, String>(); var column = 0
        var cellType = ""; var inCell = false; var inValue = false; val value = StringBuilder()
        while (p.next() != XmlPullParser.END_DOCUMENT) when (p.eventType) {
            XmlPullParser.START_TAG -> when (p.name) {
                "row" -> { rowNo = p.getAttributeValue(null, "r")?.toIntOrNull() ?: rowNo + 1; cells = linkedMapOf() }
                "c" -> { inCell = true; cellType = p.getAttributeValue(null, "t").orEmpty(); column = columnIndex(p.getAttributeValue(null, "r").orEmpty()); value.setLength(0) }
                "v", "t" -> if (inCell) inValue = true
            }
            XmlPullParser.TEXT -> if (inValue) value.append(p.text)
            XmlPullParser.END_TAG -> when (p.name) {
                "v", "t" -> if (inCell) inValue = false
                "c" -> {
                    val raw = value.toString()
                    cells[column] = if (cellType == "s") shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty() else raw
                    inCell = false; inValue = false
                }
                "row" -> rows += rowNo to cells.toMap()
            }
        }
        return rows
    }

    private fun columnIndex(reference: String): Int {
        var value = 0
        reference.takeWhile { it.isLetter() }.uppercase().forEach { value = value * 26 + (it - 'A' + 1) }
        return (value - 1).coerceAtLeast(0)
    }
}

internal fun savePendingExcelImport(context: Context, rows: List<ExcelAssetRow>) {
    val array = org.json.JSONArray()
    rows.forEach { row ->
        val custom = org.json.JSONObject(); row.customValues.forEach { (key, value) -> custom.put(key, value) }
        array.put(org.json.JSONObject().put("sheet", row.sheetName).put("branch", row.branchName)
            .put("cabinet", row.cabinetLabel).put("type", row.type).put("number", row.inventoryNumber)
            .put("name", row.displayName).put("serial", row.serialNumber).put("notes", row.notes)
            .put("row", row.sourceRow).put("brand", row.brand).put("model", row.model).put("custom", custom)
            .put("mappedBranch", row.mappedBranchId).put("mappedCabinet", row.mappedCabinetId).put("mappedWorkplace", row.mappedWorkplaceId)
            .put("skipped", row.skipped))
    }
    context.getSharedPreferences("kaen_excel_import", Context.MODE_PRIVATE).edit()
        .putString("pending_rows", array.toString()).apply()
}

internal fun loadPendingExcelImport(context: Context): List<ExcelAssetRow> = runCatching {
    val raw = context.getSharedPreferences("kaen_excel_import", Context.MODE_PRIVATE).getString("pending_rows", "[]") ?: "[]"
    val array = org.json.JSONArray(raw)
    (0 until array.length()).mapNotNull { index ->
        val item = array.optJSONObject(index) ?: return@mapNotNull null
        val customJson = item.optJSONObject("custom") ?: org.json.JSONObject()
        val custom = customJson.keys().asSequence().associateWith { customJson.optString(it) }
        ExcelAssetRow(item.optString("sheet"), item.optString("branch"), item.optString("cabinet"), item.optString("type"),
            item.optString("number"), item.optString("name"), item.optString("serial"), item.optString("notes"),
            item.optInt("row"), item.optString("brand"), item.optString("model"), custom,
            item.optLong("mappedBranch").takeIf { item.has("mappedBranch") && !item.isNull("mappedBranch") },
            item.optLong("mappedCabinet").takeIf { item.has("mappedCabinet") && !item.isNull("mappedCabinet") },
            item.optLong("mappedWorkplace").takeIf { item.has("mappedWorkplace") && !item.isNull("mappedWorkplace") }, item.optBoolean("skipped"))
    }
}.getOrDefault(emptyList())
