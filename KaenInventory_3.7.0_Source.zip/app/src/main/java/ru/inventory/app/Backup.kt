package ru.inventory.app

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Backup {
    fun create(context: Context, uri: Uri) {
        val db = InventoryDatabase.get(context)
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { }
        val databaseFile = context.getDatabasePath("inventory.db")
        context.contentResolver.openOutputStream(uri)?.use { output ->
            ZipOutputStream(output).use { zip ->
                if (databaseFile.exists()) {
                    zip.putNextEntry(ZipEntry("database/inventory.db"))
                    databaseFile.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
                val photos = File(context.filesDir, "photos")
                if (photos.exists()) photos.walkTopDown().filter { it.isFile }.forEach { file ->
                    val relative = file.relativeTo(photos).invariantSeparatorsPath
                    zip.putNextEntry(ZipEntry("photos/$relative"))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
                listOf("kaen_custom_characteristics.xml", "kaen_asset_characteristics.xml").forEach { settingsName ->
                    val settingsFile = File(context.applicationInfo.dataDir, "shared_prefs/$settingsName")
                    if (settingsFile.exists()) {
                        zip.putNextEntry(ZipEntry("settings/$settingsName"))
                        settingsFile.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
                zip.putNextEntry(ZipEntry("backup-info.txt"))
                zip.write("KaenInventory 3.1 backup".toByteArray())
                zip.closeEntry()
            }
        } ?: error("Не удалось открыть файл для записи")
    }

    fun restore(context: Context, uri: Uri) {
        val temp = File(context.cacheDir, "inventory-restore").apply { deleteRecursively(); mkdirs() }
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name.replace('\\', '/')
                    require(!name.startsWith("/") && !name.split('/').contains("..")) { "Некорректный архив" }
                    val target = File(temp, name)
                    if (entry.isDirectory) target.mkdirs() else {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { zip.copyTo(it) }
                    }
                    zip.closeEntry(); entry = zip.nextEntry
                }
            }
        } ?: error("Не удалось прочитать архив")
        val sourceDb = File(temp, "database/inventory.db")
        require(sourceDb.exists()) { "В архиве нет базы данных" }
        InventoryDatabase.closeForRestore()
        val db = context.getDatabasePath("inventory.db")
        db.parentFile?.mkdirs()
        File(db.path + "-wal").delete(); File(db.path + "-shm").delete(); db.delete()
        sourceDb.copyTo(db, overwrite = true)
        val targetPhotos = File(context.filesDir, "photos")
        targetPhotos.deleteRecursively()
        val sourcePhotos = File(temp, "photos")
        if (sourcePhotos.exists()) sourcePhotos.copyRecursively(targetPhotos, overwrite = true)
        listOf("kaen_custom_characteristics.xml", "kaen_asset_characteristics.xml").forEach { settingsName ->
            val sourceSettings = File(temp, "settings/$settingsName")
            if (sourceSettings.exists()) {
                val targetSettings = File(context.applicationInfo.dataDir, "shared_prefs/$settingsName")
                targetSettings.parentFile?.mkdirs()
                sourceSettings.copyTo(targetSettings, overwrite = true)
            }
        }
        temp.deleteRecursively()
    }
}
