package ru.inventory.app

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Exporter {
    private fun xml(v:String)=v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
    private fun col(i:Int):String { var n=i+1;var s="";while(n>0){val r=(n-1)%26;s=('A'+r)+s;n=(n-1)/26};return s }
    private fun workbook(file:File,sheets:List<Pair<String,List<List<String>>>>){
        ZipOutputStream(file.outputStream().buffered()).use { z ->
            fun put(path:String,data:String){z.putNextEntry(ZipEntry(path));z.write(data.toByteArray(Charsets.UTF_8));z.closeEntry()}
            put("[Content_Types].xml","""<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${sheets.indices.joinToString(""){"<Override PartName=\"/xl/worksheets/sheet${it+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"}}</Types>""")
            put("_rels/.rels","""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            put("xl/workbook.xml","""<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.mapIndexed{i,s->"<sheet name=\"${xml(s.first.take(31))}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"/>"}.joinToString("")}</sheets></workbook>""")
            put("xl/_rels/workbook.xml.rels","""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.indices.joinToString(""){"<Relationship Id=\"rId${it+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${it+1}.xml\"/>"}}</Relationships>""")
            sheets.forEachIndexed { index, sheet ->
                val rows=sheet.second
                val body=rows.mapIndexed{ri,row->"<row r=\"${ri+1}\">${row.mapIndexed{ci,value->"<c r=\"${col(ci)}${ri+1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xml(value)}</t></is></c>"}.joinToString("")}</row>"}.joinToString("")
                put("xl/worksheets/sheet${index+1}.xml","""<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" state="frozen"/></sheetView></sheetViews><sheetData>$body</sheetData><autoFilter ref="A1:${col((rows.firstOrNull()?.size?:1)-1)}${rows.size}"/></worksheet>""")
            }
        }
    }
    /** Формирует ведомость в стиле бумажного образца: отдельный лист на каждый филиал,
     * объединённые ячейки кабинетов, границы, перенос текста и альбомная печать. */
    fun assetsXlsx(c:Context,assets:List<Asset>,branches:List<Branch>,cabinets:List<Cabinet>,workplaces:List<Workplace>):File {
        val active = assets.sortedWith(compareBy<Asset>({ branches.firstOrNull { b -> b.id == it.branchId }?.name.orEmpty() }, { cabinets.firstOrNull { x -> x.id == it.cabinetId }?.name.orEmpty() }, { it.type }, { it.inventoryNumber }))
        val branchGroups = if (branches.isEmpty()) listOf("Все имущество" to active) else branches.map { b -> b.name to active.filter { it.branchId == b.id } }.filter { it.second.isNotEmpty() }
        val groups = branchGroups.ifEmpty { listOf("Все имущество" to active) }
        val customArray = runCatching { org.json.JSONArray(c.getSharedPreferences("kaen_custom_characteristics", Context.MODE_PRIVATE).getString("items", "[]") ?: "[]") }.getOrNull()
        val customDefinitions: List<Pair<String, String>> = (0 until (customArray?.length() ?: 0)).mapNotNull { index ->
            val item = customArray?.optJSONObject(index) ?: return@mapNotNull null
            val id = item.optString("id"); val name = item.optString("name")
            if (id.isBlank() || name.isBlank()) null else id to name
        }
        val safeNames = mutableSetOf<String>()
        val sheets = groups.map { (branchName, branchAssets) ->
            var sheetName = branchName.replace(Regex("[\\/\\?*\\[\\]:]"), " ").take(31).ifBlank { "Имущество" }
            var candidate = sheetName; var suffix = 2
            while (!safeNames.add(candidate.lowercase())) { candidate = (sheetName.take(27) + " ($suffix)").take(31); suffix++ }
            val headers: List<String> = listOf("Кабинет", "Тип оборудования", "Инвентарный номер", "Наименование / модель", "Серийный номер (S/N)", "IP-адрес", "Операционная система", "Примечание", "Ответственный") + customDefinitions.map { it.second }
            val extra = List(headers.size - 1) { "" }
            val rows = mutableListOf<List<String>>()
            rows += listOf("ВЕДОМОСТЬ УЧЁТА ИМУЩЕСТВА") + extra
            rows += listOf("Филиал: $branchName") + extra
            rows += List(headers.size) { "" }
            rows.add(headers)
            val mergeRanges = mutableListOf<Pair<Int,Int>>()
            var rowNo = 5
            val cabinetGroups = branchAssets.groupBy { it.cabinetId to it.workplaceId }.toList().sortedWith(
                compareBy<Pair<Pair<Long, Long?>, List<Asset>>> { group -> cabinets.firstOrNull { c -> c.id == group.first.first }?.name.orEmpty() }
                    .thenBy { group -> group.first.second?.let { id -> workplaces.firstOrNull { w -> w.id == id }?.name }.orEmpty() }
            )
            cabinetGroups.forEach { (location, items) ->
                val start = rowNo
                val cabinetName = cabinets.firstOrNull { it.id == location.first }?.name.orEmpty()
                val workplaceName = location.second?.let { id -> workplaces.firstOrNull { it.id == id }?.name }
                val cabinetLabel = cabinetName + (workplaceName?.let { " / $it" } ?: " / Общее имущество")
                items.sortedWith(compareBy<Asset>({ it.type }, { it.inventoryNumber })).forEachIndexed { itemIndex, a ->
                    val customValues: List<String> = runCatching<List<String>> {
                        val prefs = c.getSharedPreferences("kaen_asset_characteristics", Context.MODE_PRIVATE)
                        val raw = prefs.getString("asset_${a.id}", null) ?: prefs.getString("asset_${a.inventoryNumber}", "{}")
                        val json = org.json.JSONObject(raw ?: "{}")
                        customDefinitions.map { (id, _) -> json.optString(id) }
                    }.getOrDefault(List(customDefinitions.size) { "" })
                    rows += listOf(if (itemIndex == 0) cabinetLabel else "", a.type, a.inventoryNumber, listOf(a.name, a.brand, a.model).filter { it.isNotBlank() }.joinToString(" · "), a.serialNumber, "", "", a.notes, "") + customValues
                    rowNo++
                }
                if (rowNo - start > 1) mergeRanges += start to (rowNo - 1)
            }
            if (branchAssets.isEmpty()) rows += listOf("Нет данных") + List(headers.size - 1) { "" }
            RegisterSheet(sheetName, rows, mergeRanges)
        }
        return File(c.cacheDir,"kaen-inventory-register.xlsx").also { writeRegisterWorkbook(it, sheets) }
    }

    private data class RegisterSheet(val name:String, val rows:List<List<String>>, val cabinetMerges:List<Pair<Int,Int>>)

    private fun writeRegisterWorkbook(file:File, sheets:List<RegisterSheet>) {
        ZipOutputStream(file.outputStream().buffered()).use { z ->
            fun put(path:String, data:String) { z.putNextEntry(ZipEntry(path)); z.write(data.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            val contentOverrides = sheets.indices.joinToString("") { i ->
                "<Override PartName=\"/xl/worksheets/sheet${i+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
            }
            put("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>$contentOverrides</Types>""")
            put("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            val sheetTags = sheets.mapIndexed { i,s -> "<sheet name=\"${xml(s.name)}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"/>" }.joinToString("")
            put("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>$sheetTags</sheets></workbook>""")
            val sheetRels = sheets.indices.joinToString("") { i ->
                "<Relationship Id=\"rId${i+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${i+1}.xml\"/>"
            }
            put("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$sheetRels<Relationship Id="rId${sheets.size+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>""")
            put("xl/styles.xml", """<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="16"/><color rgb="FF173F5F"/><name val="Arial"/></font><font><b/><sz val="9"/><color rgb="FFFFFFFF"/><name val="Arial"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF176B87"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE4F2F4"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FF687D86"/></left><right style="thin"><color rgb="FF687D86"/></right><top style="thin"><color rgb="FF687D86"/></top><bottom style="thin"><color rgb="FF687D86"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="6"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf><xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>""")
            fun col(i:Int):String { var n=i+1; var out=""; while(n>0){val r=(n-1)%26;out=('A'+r)+out;n=(n-1)/26};return out }
            sheets.forEachIndexed { index, sheet ->
                val body = sheet.rows.mapIndexed { ri,row ->
                    val cells = row.mapIndexed { ci,value ->
                        val style = when(ri){0->1;1->2;3->3;else->if(ci==0)5 else 4}
                        "<c r=\"${col(ci)}${ri+1}\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xml(value)}</t></is></c>"
                    }.joinToString("")
                    val height = when(ri){0->30;1->22;2->8;3->38;else->32}
                    "<row r=\"${ri+1}\" ht=\"$height\" customHeight=\"1\">$cells</row>"
                }.joinToString("")
                val last = sheet.rows.size
                val lastColumn = col((sheet.rows.firstOrNull()?.size ?: 9) - 1)
                val merges = mutableListOf("A1:${lastColumn}1", "A2:${lastColumn}2")
                sheet.cabinetMerges.forEach { (a,b) -> merges += "A$a:A$b" }
                val mergeXml = "<mergeCells count=\"${merges.size}\">${merges.joinToString("") { ref -> "<mergeCell ref=\"$ref\"/>" }}</mergeCells>"
                val baseWidths = listOf(23,20,19,35,22,16,22,30,24)
                val widths = (0 until (sheet.rows.firstOrNull()?.size ?: 9)).map { baseWidths.getOrElse(it) { 22 } }
                val cols = widths.mapIndexed { i,w -> "<col min=\"${i+1}\" max=\"${i+1}\" width=\"$w\" customWidth=\"1\"/>" }.joinToString("")
                val sheetXml = """<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView showGridLines="0" workbookViewId="0"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData>$mergeXml<autoFilter ref="A4:${col((sheet.rows.firstOrNull()?.size ?: 9) - 1)}$last"/><pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/><pageSetup orientation="landscape" paperSize="9" fitToWidth="1" fitToHeight="0"/><printOptions horizontalCentered="1"/></worksheet>"""
                put("xl/worksheets/sheet${index+1}.xml", sheetXml)
            }
        }
    }

    fun movementsXlsx(c: Context, movements: List<Movement>): File {
        val rows = mutableListOf(listOf("Инвентарный номер", "Название", "Откуда — филиал", "Откуда — кабинет", "Откуда — рабочее место", "Куда — филиал", "Куда — кабинет", "Куда — рабочее место", "Дата", "Причина", "Комментарий"))
        val date = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale("ru"))
        movements.forEach { m -> rows.add(listOf(m.inventoryNumber, m.assetName, m.fromBranch, m.fromCabinet, m.fromWorkplace, m.toBranch, m.toCabinet, m.toWorkplace, date.format(java.util.Date(m.movedAt)), m.reason, m.comment)) }
        return File(c.cacheDir, "movement-history.xlsx").also { workbook(it, listOf("История перемещений" to rows)) }
    }

    fun auditXlsx(c:Context,audit:Audit?,items:List<AuditItem>):File {
        val rows=mutableListOf(listOf("Инвентарный номер","Название","Ожидаемое место","Фактическое место","Результат","Примечание"))
        items.forEach{rows.add(listOf(it.inventoryNumber,it.assetName,it.expectedLocation,it.actualLocation,it.status,it.notes))}
        return File(c.cacheDir,"audit.xlsx").also{workbook(it,listOf((audit?.title?:"Проверка") to rows))}
    }
    fun assetsPdf(c:Context,assets:List<Asset>,branches:List<Branch>,cabinets:List<Cabinet>,workplaces:List<Workplace>):File {
        val doc=PdfDocument();val paint=Paint().apply{textSize=8f};var pageNo=1;var page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());var canvas=page.canvas;var y=38f
        paint.textSize=14f;canvas.drawText("Ведомость инвентаризации",30f,y,paint);y+=26f;paint.textSize=8f
        assets.forEach{a->if(y>810){doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());canvas=page.canvas;y=35f};val loc="${branches.firstOrNull{it.id==a.branchId}?.name.orEmpty()} / ${cabinets.firstOrNull{it.id==a.cabinetId}?.name.orEmpty()} / ${workplaces.firstOrNull{it.id==a.workplaceId}?.name?:"Кабинет"}";canvas.drawText("${a.inventoryNumber} | ${a.name} | ${a.serialNumber} | $loc | ${a.condition}".take(125),30f,y,paint);y+=15f}
        doc.finishPage(page);val f=File(c.cacheDir,"inventory.pdf");FileOutputStream(f).use{doc.writeTo(it)};doc.close();return f
    }
}
